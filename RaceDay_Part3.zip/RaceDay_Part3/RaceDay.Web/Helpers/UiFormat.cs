using System.Globalization;
using System.Text.RegularExpressions;

namespace RaceDay.Web.Helpers;

/// <summary>Presentation helpers only (formatting and CSS class names) - no business rules live in the MVC app.</summary>
public static class UiFormat
{
    public static readonly string[] EventTypes = { "Running", "Walking", "Cycling" };
    public static readonly string[] EventStatuses = { "Upcoming", "Open", "Closed", "Completed", "Cancelled" };
    public static readonly string[] ResultStatuses = { "Finished", "DNF", "DNS", "DSQ" };
    public static readonly string[] Provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North West", "Northern Cape", "Western Cape" };

    private static readonly Regex SafeImagePath = new(@"^(banners|profiles)/[A-Za-z0-9]+\.[A-Za-z0-9]+$", RegexOptions.Compiled);

    public static string Duration(int? seconds)
    {
        if (seconds is null) return "—";
        var s = seconds.Value;
        return $"{s / 3600}:{s % 3600 / 60:00}:{s % 60:00}";
    }

    public static string Ordinal(int n)
    {
        if (n % 100 is 11 or 12 or 13) return n + "th";
        return (n % 10) switch { 1 => n + "st", 2 => n + "nd", 3 => n + "rd", _ => n + "th" };
    }

    public static string ResultStatusLabel(string status) => status switch
    {
        "DNF" => "Did not finish",
        "DNS" => "Did not start",
        "DSQ" => "Disqualified",
        _ => status
    };

    /// <summary>e.g. "47th out of 312 finishers".</summary>
    public static string PositionText(int? position, int totalFinishers, string resultStatus)
    {
        if (resultStatus != "Finished") return ResultStatusLabel(resultStatus);
        if (position is null) return "—";
        return totalFinishers > 0 ? $"{Ordinal(position.Value)} out of {totalFinishers} finishers" : Ordinal(position.Value);
    }

    public static string EnrolmentBadgeClass(string displayStatus) => displayStatus switch
    {
        "Confirmed" => "status-confirmed",
        "Cancelled" => "status-cancelled",
        "Completed" => "status-completed",
        _ => "status-pending"
    };

    public static string EventStatusBadgeClass(string status) => status switch
    {
        "Open" => "status-confirmed",
        "Closed" => "status-pending",
        "Cancelled" => "status-cancelled",
        "Completed" => "status-completed",
        _ => "status-upcoming"
    };

    public static string EventTypeIcon(string type) => type switch
    {
        "Cycling" => "bi-bicycle",
        "Walking" => "bi-person-walking",
        _ => "bi-lightning-charge-fill"
    };

    public static string Date(DateOnly date) => date.ToString("ddd, d MMM yyyy", CultureInfo.InvariantCulture);
    public static string ShortDate(DateOnly date) => date.ToString("d MMM yyyy", CultureInfo.InvariantCulture);
    public static string Time(TimeOnly time) => time.ToString("HH:mm", CultureInfo.InvariantCulture);
    public static string Distance(decimal km) => km.ToString("0.##", CultureInfo.InvariantCulture) + " km";
    public static string Money(decimal amount) => amount == 0 ? "Free" : "R " + amount.ToString("N2", CultureInfo.InvariantCulture);

    public static int ToSeconds(int hours, int minutes, int seconds) => hours * 3600 + minutes * 60 + seconds;

    public static bool TryParseDate(string? value, out DateOnly date) =>
        DateOnly.TryParseExact(value, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date);

    public static bool TryParseTime(string? value, out TimeOnly time) =>
        TimeOnly.TryParseExact(value, new[] { "HH:mm", "HH:mm:ss" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out time);

    /// <summary>Converts an API image URL (/api/files/banners/x.jpg) into the MVC proxy URL that fetches it through the API.</summary>
    public static string? ImageSrc(string? apiUrl)
    {
        const string prefix = "/api/files/";
        if (string.IsNullOrEmpty(apiUrl) || !apiUrl.StartsWith(prefix, StringComparison.Ordinal)) return null;
        var path = apiUrl.Substring(prefix.Length);
        return SafeImagePath.IsMatch(path) ? "/Files/Image?path=" + Uri.EscapeDataString(path) : null;
    }

    public static bool IsSafeImagePath(string? path) => path is not null && SafeImagePath.IsMatch(path);
}
