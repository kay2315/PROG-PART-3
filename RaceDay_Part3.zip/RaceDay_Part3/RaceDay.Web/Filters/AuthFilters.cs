using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RaceDay.Web.Services;

namespace RaceDay.Web.Filters;

/// <summary>Restricts a controller or action to one role (e.g. "Organiser").</summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class RoleRequiredAttribute : Attribute
{
    public string Role { get; }
    public RoleRequiredAttribute(string role) => Role = role;
}

/// <summary>
/// Global filter: unauthenticated users are sent to the login page; users in the wrong role are sent to an access-denied page.
/// Add [AllowAnonymous] to actions/controllers that must stay public (login, register, error pages).
/// </summary>
public class SessionAuthFilter : IActionFilter
{
    public void OnActionExecuting(ActionExecutingContext context)
    {
        var metadata = context.ActionDescriptor.EndpointMetadata;
        if (metadata.OfType<AllowAnonymousAttribute>().Any()) return;

        var user = context.HttpContext.Session.GetCurrentUser();
        if (user is null)
        {
            var request = context.HttpContext.Request;
            var returnUrl = HttpMethods.IsGet(request.Method) ? request.Path + request.QueryString : null;
            context.Result = new RedirectToActionResult("Login", "Account", new { returnUrl });
            return;
        }

        var required = metadata.OfType<RoleRequiredAttribute>().LastOrDefault();
        if (required is not null && required.Role != user.Role)
            context.Result = new RedirectToActionResult("AccessDenied", "Home", null);
    }

    public void OnActionExecuted(ActionExecutedContext context) { }
}
