using System.ComponentModel.DataAnnotations;

namespace RaceDay.Web.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Please enter your email address."), EmailAddress(ErrorMessage = "Please enter a valid email address.")]
    public string Email { get; set; } = "";
    [Required(ErrorMessage = "Please enter your password."), DataType(DataType.Password)]
    public string Password { get; set; } = "";
    public string? ReturnUrl { get; set; }
}

public class RegisterViewModel
{
    [Required(ErrorMessage = "First name is required."), StringLength(50)]
    public string FirstName { get; set; } = "";
    [Required(ErrorMessage = "Last name is required."), StringLength(50)]
    public string LastName { get; set; } = "";
    [Required(ErrorMessage = "Email is required."), EmailAddress(ErrorMessage = "Please enter a valid email address."), StringLength(255)]
    public string Email { get; set; } = "";
    [Required(ErrorMessage = "Password is required."), MinLength(8, ErrorMessage = "Password must be at least 8 characters."), DataType(DataType.Password)]
    public string Password { get; set; } = "";
    [Required(ErrorMessage = "Please confirm your password."), Compare(nameof(Password), ErrorMessage = "The passwords do not match."), DataType(DataType.Password)]
    public string ConfirmPassword { get; set; } = "";
    [Required(ErrorMessage = "Please choose how you will use RaceDay.")]
    public string Role { get; set; } = "Participant";
}

public class EventFilter
{
    public string? Search { get; set; }
    public string? EventType { get; set; }
    public string? Province { get; set; }
    public string? City { get; set; }
    public string? DateFrom { get; set; }
    public string? DateTo { get; set; }
    public bool HasAny => !string.IsNullOrWhiteSpace(Search) || !string.IsNullOrWhiteSpace(EventType) || !string.IsNullOrWhiteSpace(Province)
        || !string.IsNullOrWhiteSpace(City) || !string.IsNullOrWhiteSpace(DateFrom) || !string.IsNullOrWhiteSpace(DateTo);
}

public class HomeViewModel
{
    public List<EventDto> Events { get; set; } = new();
    public EventFilter Filter { get; set; } = new();
}

public class EventDetailsViewModel
{
    public EventDto Event { get; set; } = null!;
    public List<EventResultDto> Results { get; set; } = new();
    public HashSet<int> EnrolledCategoryIds { get; set; } = new();
    public bool IsParticipant { get; set; }
    public bool IsOwner { get; set; }
}

public class ProfileViewModel
{
    [Required(ErrorMessage = "First name is required."), StringLength(50)]
    public string FirstName { get; set; } = "";
    [Required(ErrorMessage = "Last name is required."), StringLength(50)]
    public string LastName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
    [StringLength(20), RegularExpression(@"^[0-9+()\-\s]{7,20}$", ErrorMessage = "Enter a valid phone number.")]
    public string? Phone { get; set; }
    public string? DateOfBirth { get; set; }
    [StringLength(100)] public string? EmergencyContactName { get; set; }
    [StringLength(20), RegularExpression(@"^[0-9+()\-\s]{7,20}$", ErrorMessage = "Enter a valid emergency contact phone number.")]
    public string? EmergencyContactPhone { get; set; }
    [StringLength(100)] public string? City { get; set; }
    [StringLength(100)] public string? Province { get; set; }
    public string? ProfilePictureUrl { get; set; }
}

public class EventFormViewModel
{
    public int EventId { get; set; }
    [Required(ErrorMessage = "Event name is required."), StringLength(150, ErrorMessage = "Event name must be 150 characters or fewer.")]
    public string EventName { get; set; } = "";
    [Required(ErrorMessage = "Please choose an event type.")]
    public string EventType { get; set; } = "Running";
    [StringLength(2000, ErrorMessage = "Description must be 2000 characters or fewer.")]
    public string? Description { get; set; }
    [Required(ErrorMessage = "Event date is required.")]
    public string? EventDate { get; set; }
    [Required(ErrorMessage = "Start time is required.")]
    public string? StartTime { get; set; } = "06:30";
    [Required(ErrorMessage = "Venue is required."), StringLength(150)]
    public string Venue { get; set; } = "";
    [Required(ErrorMessage = "City is required."), StringLength(100)]
    public string City { get; set; } = "";
    [Required(ErrorMessage = "Province is required."), StringLength(100)]
    public string Province { get; set; } = "Gauteng";
    [Required(ErrorMessage = "Please choose a status.")]
    public string Status { get; set; } = "Open";
    [Required(ErrorMessage = "Distance is required."), Range(0.01, 9999, ErrorMessage = "Distance must be between 0.01 and 9999 km.")]
    public decimal? DistanceKm { get; set; }
    public string? CurrentBannerUrl { get; set; }
    public IFormFile? Banner { get; set; }
    public bool RemoveBanner { get; set; }
    public bool IsEdit => EventId > 0;
}

public class CategoryFormModel
{
    public int EventId { get; set; }
    public int CategoryId { get; set; }
    [Required(ErrorMessage = "Category name is required."), StringLength(100, ErrorMessage = "Category name must be 100 characters or fewer.")]
    public string CategoryName { get; set; } = "";
    [Required(ErrorMessage = "Distance is required."), Range(0.01, 9999, ErrorMessage = "Distance must be greater than zero.")]
    public decimal? DistanceKm { get; set; }
    [Required(ErrorMessage = "Entry fee is required (use 0 for free)."), Range(0, 1000000, ErrorMessage = "Entry fee cannot be negative.")]
    public decimal? EntryFee { get; set; }
    [Range(1, 100000, ErrorMessage = "Maximum participants must be at least 1.")]
    public int? MaximumParticipants { get; set; }
}

public class CategoriesViewModel
{
    public EventDto Event { get; set; } = null!;
}

public class EnrolmentsViewModel
{
    public EventDto Event { get; set; } = null!;
    public List<EnrolmentDto> Enrolments { get; set; } = new();
    public int? CategoryId { get; set; }
}

public class ResultsViewModel
{
    public EventDto Event { get; set; } = null!;
    public List<EnrolmentDto> Enrolments { get; set; } = new();
    public bool EventHasTakenPlace { get; set; }
}

public class ResultFormModel
{
    public int EventId { get; set; }
    public int EnrolmentId { get; set; }
    public int ResultId { get; set; }
    [Required] public string ResultStatus { get; set; } = "Finished";
    [Range(0, 99, ErrorMessage = "Hours must be between 0 and 99.")] public int Hours { get; set; }
    [Range(0, 59, ErrorMessage = "Minutes must be between 0 and 59.")] public int Minutes { get; set; }
    [Range(0, 59, ErrorMessage = "Seconds must be between 0 and 59.")] public int Seconds { get; set; }
    [Range(1, 100000, ErrorMessage = "Position must be at least 1.")] public int? FinishPosition { get; set; }
}
