namespace RaceDay.Web.Models;

// Shapes returned by the Part 2 API (JSON, case-insensitive). The MVC app holds no database access or business rules.

public record ProfileDto(string? Phone, DateOnly? DateOfBirth, string? EmergencyContactName, string? EmergencyContactPhone, string? City, string? Province, string? ProfilePictureUrl);
public record UserDto(int UserId, string FirstName, string LastName, string Email, string Role, ProfileDto? Profile);
public record LoginResponse(string Message, UserDto User);
public record CategoryDto(int CategoryId, int EventId, string CategoryName, decimal DistanceKm, decimal EntryFee, int? MaximumParticipants, int EnrolledCount);
public record EventDto(int EventId, int OrganiserId, string? OrganiserName, string EventName, string EventType, string? Description, DateOnly EventDate, TimeOnly StartTime, string Venue, string City, string Province, string Status, decimal? DistanceKm, string? BannerUrl, List<CategoryDto> Categories);
public record ResultDto(int ResultId, int EnrolmentId, int? FinishPosition, int? FinishTimeSeconds, string ResultStatus, DateTime RecordedAt);
public record EnrolmentDto(int EnrolmentId, int ParticipantId, string ParticipantName, string ParticipantEmail, int CategoryId, string CategoryName, decimal CategoryDistanceKm, int EventId, string EventName, string EventType, DateOnly EventDate, DateTime EnrolmentDate, string? RaceNumber, string PaymentStatus, string EnrolmentStatus, string DisplayStatus, ResultDto? Result);
public record EventResultDto(int ResultId, int EnrolmentId, string ParticipantName, string? RaceNumber, int CategoryId, string CategoryName, int? FinishPosition, int? FinishTimeSeconds, string ResultStatus);
public record MyResultDto(int ResultId, int EventId, string EventName, DateOnly EventDate, string CategoryName, decimal DistanceKm, int? FinishPosition, int? FinishTimeSeconds, string ResultStatus, int TotalFinishers);
public record DashboardEventDto(int EventId, string EventName, string EventType, DateOnly EventDate, string Status, int CategoryCount, int TotalEnrolments, int PendingPayments);
public record DashboardDto(int TotalEvents, int UpcomingEvents, int TotalEnrolments, int PendingPayments, List<DashboardEventDto> Events);

// Request bodies sent to the API
public record RegisterRequest(string FirstName, string LastName, string Email, string Password, string Role);
public record LoginRequest(string Email, string Password);
public record ProfileUpdateRequest(string? FirstName, string? LastName, string? Phone, DateOnly? DateOfBirth, string? EmergencyContactName, string? EmergencyContactPhone, string? City, string? Province);
public record EventRequest(string EventName, string EventType, string? Description, DateOnly EventDate, TimeOnly StartTime, string Venue, string City, string Province, string Status, decimal? DistanceKm);
public record CategoryRequest(string CategoryName, decimal DistanceKm, decimal EntryFee, int? MaximumParticipants);
public record EnrolmentRequest(int CategoryId);
public record EnrolmentUpdateRequest(string? PaymentStatus, string? EnrolmentStatus);
public record ResultRequest(int EnrolmentId, int? FinishPosition, int? FinishTimeSeconds, string ResultStatus);
public record ResultUpdateRequest(int? FinishPosition, int? FinishTimeSeconds, string ResultStatus);
