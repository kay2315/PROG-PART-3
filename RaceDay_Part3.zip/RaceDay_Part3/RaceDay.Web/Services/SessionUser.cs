using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

public record SessionUser(int UserId, string Role, string Name)
{
    public bool IsOrganiser => Role == "Organiser";
    public bool IsParticipant => Role == "Participant";
}

/// <summary>The signed-in user's identity and role live in the MVC session so every page can see them.</summary>
public static class SessionExtensions
{
    public const string ApiCookieKey = "ApiCookie";

    public static SessionUser? GetCurrentUser(this ISession session)
    {
        var role = session.GetString("Role");
        if (!int.TryParse(session.GetString("UserId"), out var id) || string.IsNullOrEmpty(role) || string.IsNullOrEmpty(session.GetString(ApiCookieKey))) return null;
        return new SessionUser(id, role, session.GetString("Name") ?? "");
    }

    public static void SignIn(this ISession session, UserDto user, string apiCookie)
    {
        session.SetString("UserId", user.UserId.ToString());
        session.SetString("Role", user.Role);
        session.SetString("Name", $"{user.FirstName} {user.LastName}".Trim());
        session.SetString(ApiCookieKey, apiCookie);
    }
}
