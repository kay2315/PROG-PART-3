using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

public class ApiResult<T>
{
    public bool Success { get; init; }
    public T? Data { get; init; }
    public string Error { get; init; } = "";
    public HttpStatusCode StatusCode { get; init; }
    public bool Unauthorized => StatusCode == HttpStatusCode.Unauthorized;
}

public record ApiFile(byte[] Bytes, string ContentType);

/// <summary>
/// The only gateway to data in the MVC app: every call goes to the Part 2 REST API, forwarding the API session cookie
/// that is stored in the user's MVC session. Errors are converted to friendly messages (never raw exceptions).
/// </summary>
public class ApiClient
{
    private const string SessionCookieName = ".AspNetCore.Session";
    private const string Unavailable = "The RaceDay service is currently unavailable. Please try again shortly.";
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _accessor;
    private readonly ILogger<ApiClient> _log;

    public ApiClient(HttpClient http, IHttpContextAccessor accessor, ILogger<ApiClient> log)
    {
        _http = http; _accessor = accessor; _log = log;
    }

    private ISession Session => _accessor.HttpContext!.Session;

    public Task<ApiResult<T>> GetAsync<T>(string url) => SendAsync<T>(HttpMethod.Get, url, null);
    public Task<ApiResult<T>> PostAsync<T>(string url, object body) => SendAsync<T>(HttpMethod.Post, url, JsonContent.Create(body, options: Json));
    public Task<ApiResult<T>> PutAsync<T>(string url, object body) => SendAsync<T>(HttpMethod.Put, url, JsonContent.Create(body, options: Json));
    public Task<ApiResult<bool>> DeleteAsync(string url) => SendAsync<bool>(HttpMethod.Delete, url, null);

    /// <summary>Forwards an uploaded image to the API (which stores it in Azure Blob Storage).</summary>
    public Task<ApiResult<T>> UploadAsync<T>(string url, IFormFile file)
    {
        var content = new MultipartFormDataContent();
        var fileContent = new StreamContent(file.OpenReadStream());
        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(string.IsNullOrWhiteSpace(file.ContentType) ? "application/octet-stream" : file.ContentType);
        content.Add(fileContent, "file", Path.GetFileName(file.FileName));
        return SendAsync<T>(HttpMethod.Post, url, content);
    }

    public async Task<ApiResult<ApiFile>> GetFileAsync(string url)
    {
        try
        {
            using var req = NewRequest(HttpMethod.Get, url, null);
            using var res = await _http.SendAsync(req);
            if (!res.IsSuccessStatusCode) return new ApiResult<ApiFile> { Success = false, StatusCode = res.StatusCode, Error = "File not found." };
            var bytes = await res.Content.ReadAsByteArrayAsync();
            return new ApiResult<ApiFile> { Success = true, StatusCode = res.StatusCode, Data = new ApiFile(bytes, res.Content.Headers.ContentType?.ToString() ?? "application/octet-stream") };
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            _log.LogWarning(ex, "API file request failed: {Url}", url);
            return new ApiResult<ApiFile> { Success = false, StatusCode = HttpStatusCode.ServiceUnavailable, Error = Unavailable };
        }
    }

    public async Task<ApiResult<UserDto>> RegisterAsync(RegisterRequest request)
    {
        var r = await SendAsync<JsonElement>(HttpMethod.Post, "api/auth/register", JsonContent.Create(request, options: Json), clearSessionOn401: false);
        return new ApiResult<UserDto> { Success = r.Success, StatusCode = r.StatusCode, Error = r.Error };
    }

    /// <summary>Logs in against the API and captures its session cookie so later calls act as this user.</summary>
    public async Task<(ApiResult<LoginResponse> Result, string? Cookie)> LoginAsync(string email, string password)
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Post, "api/auth/login") { Content = JsonContent.Create(new LoginRequest(email, password), options: Json) };
            using var res = await _http.SendAsync(req);
            var text = await res.Content.ReadAsStringAsync();
            if (!res.IsSuccessStatusCode)
            {
                var error = res.StatusCode == HttpStatusCode.Unauthorized ? "Incorrect email or password." : FriendlyError(res.StatusCode, text);
                return (new ApiResult<LoginResponse> { Success = false, StatusCode = res.StatusCode, Error = error }, null);
            }
            string? cookie = null;
            if (res.Headers.TryGetValues("Set-Cookie", out var values))
            {
                var raw = values.FirstOrDefault(v => v.StartsWith(SessionCookieName + "=", StringComparison.Ordinal));
                if (raw is not null) cookie = raw.Split(';')[0];
            }
            var data = JsonSerializer.Deserialize<LoginResponse>(text, Json);
            if (cookie is null || data is null)
                return (new ApiResult<LoginResponse> { Success = false, StatusCode = HttpStatusCode.BadGateway, Error = "We could not sign you in right now. Please try again." }, null);
            return (new ApiResult<LoginResponse> { Success = true, StatusCode = res.StatusCode, Data = data }, cookie);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException)
        {
            _log.LogWarning(ex, "API login failed");
            return (new ApiResult<LoginResponse> { Success = false, StatusCode = HttpStatusCode.ServiceUnavailable, Error = Unavailable }, null);
        }
    }

    public async Task LogoutAsync()
    {
        await SendAsync<bool>(HttpMethod.Post, "api/auth/logout", null, clearSessionOn401: false);
        Session.Clear();
    }

    private HttpRequestMessage NewRequest(HttpMethod method, string url, HttpContent? content)
    {
        var req = new HttpRequestMessage(method, url) { Content = content };
        var cookie = Session.GetString(SessionExtensions.ApiCookieKey);
        if (!string.IsNullOrEmpty(cookie)) req.Headers.TryAddWithoutValidation("Cookie", cookie);
        return req;
    }

    private async Task<ApiResult<T>> SendAsync<T>(HttpMethod method, string url, HttpContent? content, bool clearSessionOn401 = true)
    {
        try
        {
            using var req = NewRequest(method, url, content);
            using var res = await _http.SendAsync(req);
            var text = await res.Content.ReadAsStringAsync();
            if (res.IsSuccessStatusCode)
            {
                T? data = default;
                if (!string.IsNullOrWhiteSpace(text))
                {
                    try { data = JsonSerializer.Deserialize<T>(text, Json); }
                    catch (JsonException ex)
                    {
                        _log.LogError(ex, "Unexpected API response for {Url}", url);
                        return new ApiResult<T> { Success = false, StatusCode = HttpStatusCode.BadGateway, Error = "We received an unexpected response from the RaceDay service." };
                    }
                }
                return new ApiResult<T> { Success = true, Data = data, StatusCode = res.StatusCode };
            }
            if (res.StatusCode == HttpStatusCode.Unauthorized && clearSessionOn401) Session.Clear();   // API session expired
            if ((int)res.StatusCode >= 500) _log.LogError("API {Method} {Url} returned {Status}: {Body}", method, url, (int)res.StatusCode, text);
            return new ApiResult<T> { Success = false, StatusCode = res.StatusCode, Error = FriendlyError(res.StatusCode, text) };
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            _log.LogWarning(ex, "API request failed: {Method} {Url}", method, url);
            return new ApiResult<T> { Success = false, StatusCode = HttpStatusCode.ServiceUnavailable, Error = Unavailable };
        }
    }

    public static string FriendlyError(HttpStatusCode status, string body)
    {
        if ((int)status >= 500) return "The RaceDay service had a problem. Please try again in a moment.";
        var message = TryReadMessage(body);
        if (message is not null) return message;
        return status switch
        {
            HttpStatusCode.Unauthorized => "Please log in to continue.",
            HttpStatusCode.Forbidden => "You do not have permission to do that.",
            HttpStatusCode.NotFound => "We couldn't find what you were looking for.",
            HttpStatusCode.Conflict => "That conflicts with existing information.",
            _ => "The request could not be completed. Please check your input and try again."
        };
    }

    // The API returns plain JSON strings for validation messages, or ProblemDetails objects.
    private static string? TryReadMessage(string body)
    {
        if (string.IsNullOrWhiteSpace(body)) return null;
        try
        {
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            if (root.ValueKind == JsonValueKind.String) return root.GetString();
            if (root.ValueKind == JsonValueKind.Object)
            {
                if (root.TryGetProperty("detail", out var detail) && detail.ValueKind == JsonValueKind.String) return detail.GetString();
                if (root.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Object)
                    foreach (var field in errors.EnumerateObject())
                        foreach (var item in field.Value.EnumerateArray())
                            if (item.ValueKind == JsonValueKind.String) return item.GetString();
            }
        }
        catch (Exception ex) when (ex is JsonException or InvalidOperationException) { }
        return null;
    }
}
