// RaceDay site scripts: confirmations, double-submit protection, image preview.
(function () {
    // Confirm destructive actions: <button data-confirm="Are you sure?"> or <form data-confirm="...">
    document.addEventListener('submit', function (e) {
        var form = e.target;
        var message = (e.submitter && e.submitter.dataset.confirm) || form.dataset.confirm;
        if (message && !window.confirm(message)) { e.preventDefault(); return; }
        // Prevent accidental double submits
        if (!e.defaultPrevented) {
            var buttons = form.querySelectorAll('button[type=submit]');
            window.setTimeout(function () { buttons.forEach(function (b) { b.disabled = true; }); }, 0);
        }
    });

    // Live preview for image inputs: <input type="file" data-preview="#imgId">
    document.querySelectorAll('input[type=file][data-preview]').forEach(function (input) {
        input.addEventListener('change', function () {
            var target = document.querySelector(input.dataset.preview);
            var file = input.files && input.files[0];
            if (!target || !file) return;
            target.src = URL.createObjectURL(file);
            target.classList.remove('d-none');
            var placeholder = document.querySelector(input.dataset.placeholder || '');
            if (placeholder) placeholder.classList.add('d-none');
        });
    });

    // Auto-dismiss success messages
    document.querySelectorAll('.alert-success.rd-flash').forEach(function (el) {
        window.setTimeout(function () {
            if (window.bootstrap) { bootstrap.Alert.getOrCreateInstance(el).close(); }
        }, 6000);
    });
})();
