using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class ProfileController : AppController
{
    private readonly ApiClient _api;
    public ProfileController(ApiClient api) => _api = api;

    private static ProfileViewModel ToModel(UserDto u) => new()
    {
        FirstName = u.FirstName, LastName = u.LastName, Email = u.Email, Role = u.Role,
        Phone = u.Profile?.Phone, DateOfBirth = u.Profile?.DateOfBirth?.ToString("yyyy-MM-dd"),
        EmergencyContactName = u.Profile?.EmergencyContactName, EmergencyContactPhone = u.Profile?.EmergencyContactPhone,
        City = u.Profile?.City, Province = u.Profile?.Province, ProfilePictureUrl = u.Profile?.ProfilePictureUrl
    };

    public async Task<IActionResult> Index()
    {
        var result = await _api.GetAsync<UserDto>("api/users/me");
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success || result.Data is null)
        {
            Fail(result.Error);
            return RedirectToAction("Index", "Home");
        }
        return View(ToModel(result.Data));
    }

    [HttpPost]
    public async Task<IActionResult> Update(ProfileViewModel model)
    {
        DateOnly? dob = null;
        if (!string.IsNullOrWhiteSpace(model.DateOfBirth))
        {
            if (UiFormat.TryParseDate(model.DateOfBirth, out var parsed)) dob = parsed;
            else ModelState.AddModelError(nameof(model.DateOfBirth), "Enter a valid date of birth.");
        }
        if (!ModelState.IsValid) return await RedisplayAsync(model);

        var result = await _api.PutAsync<UserDto>("api/users/me", new ProfileUpdateRequest(model.FirstName, model.LastName, model.Phone, dob,
            model.EmergencyContactName, model.EmergencyContactPhone, model.City, model.Province));
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError("", result.Error);
            return await RedisplayAsync(model);
        }
        HttpContext.Session.SetString("Name", $"{result.Data.FirstName} {result.Data.LastName}".Trim());
        Success("Your profile has been updated.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> UploadPicture(IFormFile? picture)
    {
        if (picture is null || picture.Length == 0)
        {
            Fail("Please choose an image to upload.");
            return RedirectToAction(nameof(Index));
        }
        var result = await _api.UploadAsync<UserDto>("api/users/me/picture", picture);
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success("Your profile picture has been updated."); else Fail(result.Error);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> RemovePicture()
    {
        var result = await _api.DeleteAsync("api/users/me/picture");
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success("Your profile picture was removed."); else Fail(result.Error);
        return RedirectToAction(nameof(Index));
    }

    // Keep what the user typed but refresh read-only fields (email, picture) from the API.
    private async Task<IActionResult> RedisplayAsync(ProfileViewModel model)
    {
        var current = await _api.GetAsync<UserDto>("api/users/me");
        if (Guard(current) is { } redirect) return redirect;
        if (current.Success && current.Data is not null)
        {
            model.Email = current.Data.Email; model.Role = current.Data.Role;
            model.ProfilePictureUrl = current.Data.Profile?.ProfilePictureUrl;
        }
        return View("Index", model);
    }
}
