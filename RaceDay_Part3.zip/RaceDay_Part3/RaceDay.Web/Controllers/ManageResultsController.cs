using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[RoleRequired("Organiser")]
public class ManageResultsController : AppController
{
    private readonly ApiClient _api;
    public ManageResultsController(ApiClient api) => _api = api;

    // id = event id
    public async Task<IActionResult> Index(int id)
    {
        var ev = await _api.GetAsync<EventDto>($"api/events/{id}");
        if (Guard(ev) is { } redirect) return redirect;
        if (!ev.Success || ev.Data is null) return NotFound();
        if (ev.Data.OrganiserId != CurrentUser.UserId)
        {
            Fail("You can only record results for events that you created.");
            return RedirectToAction("Index", "ManageEvents");
        }

        var list = await _api.GetAsync<List<EnrolmentDto>>($"api/events/{id}/enrolments");
        if (Guard(list) is { } expired) return expired;
        if (!list.Success) Fail(list.Error);

        return View(new ResultsViewModel
        {
            Event = ev.Data,
            Enrolments = (list.Data ?? new List<EnrolmentDto>()).Where(x => x.EnrolmentStatus != "Cancelled").ToList(),
            EventHasTakenPlace = ev.Data.EventDate <= DateOnly.FromDateTime(DateTime.UtcNow)
        });
    }

    /// <summary>Creates or corrects a result; saving publishes it immediately to the participant's My Results page.</summary>
    [HttpPost]
    public async Task<IActionResult> Save(ResultFormModel model)
    {
        if (!ModelState.IsValid)
        {
            Fail(ModelErrors());
            return RedirectToAction(nameof(Index), new { id = model.EventId });
        }

        var total = UiFormat.ToSeconds(model.Hours, model.Minutes, model.Seconds);
        int? seconds = total > 0 ? total : null;
        int? position = model.ResultStatus == "Finished" ? model.FinishPosition : null;
        if (model.ResultStatus != "Finished") seconds = null;

        ApiResult<ResultDto> result = model.ResultId > 0
            ? await _api.PutAsync<ResultDto>($"api/results/{model.ResultId}", new ResultUpdateRequest(position, seconds, model.ResultStatus))
            : await _api.PostAsync<ResultDto>($"api/events/{model.EventId}/results", new ResultRequest(model.EnrolmentId, position, seconds, model.ResultStatus));
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success("Result saved and published."); else Fail(result.Error);
        return RedirectToAction(nameof(Index), new { id = model.EventId });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int resultId, int eventId)
    {
        var result = await _api.DeleteAsync($"api/results/{resultId}");
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success("Result removed."); else Fail(result.Error);
        return RedirectToAction(nameof(Index), new { id = eventId });
    }
}
