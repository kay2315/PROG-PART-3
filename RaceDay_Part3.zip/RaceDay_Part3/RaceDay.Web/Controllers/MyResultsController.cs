using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[RoleRequired("Participant")]
public class MyResultsController : AppController
{
    private readonly ApiClient _api;
    public MyResultsController(ApiClient api) => _api = api;

    public async Task<IActionResult> Index()
    {
        var result = await _api.GetAsync<List<MyResultDto>>("api/users/me/results");
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success) Fail(result.Error);
        return View(result.Data ?? new List<MyResultDto>());
    }
}
