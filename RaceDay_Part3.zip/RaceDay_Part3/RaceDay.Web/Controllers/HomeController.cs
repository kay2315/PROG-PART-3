using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class HomeController : AppController
{
    private readonly ApiClient _api;
    public HomeController(ApiClient api) => _api = api;

    /// <summary>Participant home: all upcoming events with filtering. Organisers go to their dashboard.</summary>
    public async Task<IActionResult> Index([FromQuery] EventFilter filter)
    {
        if (CurrentUser.IsOrganiser) return RedirectToAction("Dashboard", "Organiser");

        var query = new List<string> { "upcomingOnly=true" };
        void Add(string key, string? value) { if (!string.IsNullOrWhiteSpace(value)) query.Add($"{key}={Uri.EscapeDataString(value.Trim())}"); }
        Add("search", filter.Search); Add("eventType", filter.EventType); Add("province", filter.Province); Add("city", filter.City);
        if (Helpers.UiFormat.TryParseDate(filter.DateFrom, out _)) Add("dateFrom", filter.DateFrom);
        if (Helpers.UiFormat.TryParseDate(filter.DateTo, out _)) Add("dateTo", filter.DateTo);

        var result = await _api.GetAsync<List<EventDto>>("api/events?" + string.Join("&", query));
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success) Fail(result.Error);
        return View(new HomeViewModel { Events = result.Data ?? new List<EventDto>(), Filter = filter });
    }

    public IActionResult AccessDenied() => View();

    [AllowAnonymous]
    public IActionResult Error() => View();

    [AllowAnonymous]
    public IActionResult StatusPage(int code)
    {
        Response.StatusCode = code;
        ViewData["Code"] = code;
        return View();
    }
}
