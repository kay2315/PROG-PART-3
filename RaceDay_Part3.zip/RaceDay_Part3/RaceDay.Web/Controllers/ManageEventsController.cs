using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[RoleRequired("Organiser")]
public class ManageEventsController : AppController
{
    private readonly ApiClient _api;
    public ManageEventsController(ApiClient api) => _api = api;

    public async Task<IActionResult> Index()
    {
        var result = await _api.GetAsync<DashboardDto>("api/organiser/dashboard");
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success) Fail(result.Error);
        return View(result.Data?.Events ?? new List<DashboardEventDto>());
    }

    [HttpGet]
    public IActionResult Create() => View("Form", new EventFormViewModel { EventDate = DateOnly.FromDateTime(DateTime.Today.AddDays(30)).ToString("yyyy-MM-dd") });

    [HttpPost]
    public async Task<IActionResult> Create(EventFormViewModel model)
    {
        var request = BuildRequest(model);
        if (request is null || !ModelState.IsValid) return View("Form", model);

        var created = await _api.PostAsync<EventDto>("api/events", request);
        if (Guard(created) is { } redirect) return redirect;
        if (!created.Success || created.Data is null)
        {
            ModelState.AddModelError("", created.Error);
            return View("Form", model);
        }

        if (model.Banner is { Length: > 0 })
        {
            var banner = await _api.UploadAsync<EventDto>($"api/events/{created.Data.EventId}/banner", model.Banner);
            if (!banner.Success)
            {
                Fail($"The event was created, but the banner could not be uploaded: {banner.Error}");
                return RedirectToAction(nameof(Edit), new { id = created.Data.EventId });
            }
        }
        Success($"'{created.Data.EventName}' was created. Add categories so participants can enrol.");
        return RedirectToAction("Index", "ManageCategories", new { id = created.Data.EventId });
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var ev = await _api.GetAsync<EventDto>($"api/events/{id}");
        if (Guard(ev) is { } redirect) return redirect;
        if (!ev.Success || ev.Data is null) return NotFound();
        if (ev.Data.OrganiserId != CurrentUser.UserId)
        {
            Fail("You can only edit events that you created.");
            return RedirectToAction(nameof(Index));
        }
        var e = ev.Data;
        return View("Form", new EventFormViewModel
        {
            EventId = e.EventId, EventName = e.EventName, EventType = e.EventType, Description = e.Description,
            EventDate = e.EventDate.ToString("yyyy-MM-dd"), StartTime = e.StartTime.ToString("HH:mm"),
            Venue = e.Venue, City = e.City, Province = e.Province, Status = e.Status, DistanceKm = e.DistanceKm, CurrentBannerUrl = e.BannerUrl
        });
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, EventFormViewModel model)
    {
        model.EventId = id;
        var request = BuildRequest(model);
        if (request is null || !ModelState.IsValid) return await RedisplayAsync(model);

        var updated = await _api.PutAsync<EventDto>($"api/events/{id}", request);
        if (Guard(updated) is { } redirect) return redirect;
        if (!updated.Success)
        {
            if (updated.StatusCode == System.Net.HttpStatusCode.NotFound || updated.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                Fail(updated.Error);
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddModelError("", updated.Error);
            return await RedisplayAsync(model);
        }

        if (model.RemoveBanner)
        {
            await _api.DeleteAsync($"api/events/{id}/banner");
        }
        else if (model.Banner is { Length: > 0 })
        {
            var banner = await _api.UploadAsync<EventDto>($"api/events/{id}/banner", model.Banner);
            if (!banner.Success)
            {
                Fail($"The event was saved, but the banner could not be uploaded: {banner.Error}");
                return RedirectToAction(nameof(Edit), new { id });
            }
        }
        Success("Event updated.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _api.DeleteAsync($"api/events/{id}");
        if (Guard(deleted) is { } redirect) return redirect;
        if (!deleted.Success)
        {
            Fail(deleted.Error);
            return RedirectToAction(nameof(Index));
        }
        // The API deletes events without enrolments and cancels the rest, so check which happened.
        var still = await _api.GetAsync<EventDto>($"api/events/{id}");
        if (still.Success) Success("This event already has enrolments, so it was cancelled instead of deleted.");
        else Success("Event deleted.");
        return RedirectToAction(nameof(Index));
    }

    private EventRequest? BuildRequest(EventFormViewModel model)
    {
        DateOnly date = default; TimeOnly time = default;
        if (!string.IsNullOrWhiteSpace(model.EventDate) && !UiFormat.TryParseDate(model.EventDate, out date))
            ModelState.AddModelError(nameof(model.EventDate), "Enter a valid event date.");
        if (!string.IsNullOrWhiteSpace(model.StartTime) && !UiFormat.TryParseTime(model.StartTime, out time))
            ModelState.AddModelError(nameof(model.StartTime), "Enter a valid start time.");
        if (model.Banner is { Length: > 0 } && !(model.Banner.ContentType ?? "").StartsWith("image/", StringComparison.OrdinalIgnoreCase))
            ModelState.AddModelError(nameof(model.Banner), "The banner must be an image file (JPG, PNG, GIF or WEBP).");
        if (!ModelState.IsValid) return null;
        return new EventRequest(model.EventName.Trim(), model.EventType, model.Description, date, time, model.Venue.Trim(), model.City.Trim(), model.Province, model.Status, model.DistanceKm);
    }

    private async Task<IActionResult> RedisplayAsync(EventFormViewModel model)
    {
        var current = await _api.GetAsync<EventDto>($"api/events/{model.EventId}");
        if (Guard(current) is { } redirect) return redirect;
        if (current.Success && current.Data is not null) model.CurrentBannerUrl = current.Data.BannerUrl;
        return View("Form", model);
    }
}
