using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[RoleRequired("Organiser")]
public class ManageCategoriesController : AppController
{
    private readonly ApiClient _api;
    public ManageCategoriesController(ApiClient api) => _api = api;

    // id = event id
    public async Task<IActionResult> Index(int id)
    {
        var ev = await _api.GetAsync<EventDto>($"api/events/{id}");
        if (Guard(ev) is { } redirect) return redirect;
        if (!ev.Success || ev.Data is null) return NotFound();
        if (ev.Data.OrganiserId != CurrentUser.UserId)
        {
            Fail("You can only manage categories for events that you created.");
            return RedirectToAction("Index", "ManageEvents");
        }
        return View(new CategoriesViewModel { Event = ev.Data });
    }

    [HttpPost]
    public async Task<IActionResult> Add(CategoryFormModel model)
    {
        if (!ModelState.IsValid)
        {
            Fail(ModelErrors());
            return RedirectToAction(nameof(Index), new { id = model.EventId });
        }
        var result = await _api.PostAsync<CategoryDto>($"api/events/{model.EventId}/categories", ToRequest(model));
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success($"Category '{model.CategoryName.Trim()}' added."); else Fail(result.Error);
        return RedirectToAction(nameof(Index), new { id = model.EventId });
    }

    [HttpPost]
    public async Task<IActionResult> Update(CategoryFormModel model)
    {
        if (!ModelState.IsValid)
        {
            Fail(ModelErrors());
            return RedirectToAction(nameof(Index), new { id = model.EventId });
        }
        var result = await _api.PutAsync<CategoryDto>($"api/categories/{model.CategoryId}", ToRequest(model));
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success("Category updated."); else Fail(result.Error);
        return RedirectToAction(nameof(Index), new { id = model.EventId });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int categoryId, int eventId)
    {
        var result = await _api.DeleteAsync($"api/categories/{categoryId}");
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success("Category deleted."); else Fail(result.Error);
        return RedirectToAction(nameof(Index), new { id = eventId });
    }

    private static CategoryRequest ToRequest(CategoryFormModel m) =>
        new(m.CategoryName.Trim(), m.DistanceKm ?? 0, m.EntryFee ?? 0, m.MaximumParticipants);
}
