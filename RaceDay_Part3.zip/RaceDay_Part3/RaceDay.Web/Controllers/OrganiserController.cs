using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[RoleRequired("Organiser")]
public class OrganiserController : AppController
{
    private readonly ApiClient _api;
    public OrganiserController(ApiClient api) => _api = api;

    public async Task<IActionResult> Dashboard()
    {
        var result = await _api.GetAsync<DashboardDto>("api/organiser/dashboard");
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success) Fail(result.Error);
        return View(result.Data ?? new DashboardDto(0, 0, 0, 0, new List<DashboardEventDto>()));
    }
}
