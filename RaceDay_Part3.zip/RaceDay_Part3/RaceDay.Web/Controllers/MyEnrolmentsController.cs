using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[RoleRequired("Participant")]
public class MyEnrolmentsController : AppController
{
    private readonly ApiClient _api;
    public MyEnrolmentsController(ApiClient api) => _api = api;

    public async Task<IActionResult> Index()
    {
        var result = await _api.GetAsync<List<EnrolmentDto>>("api/users/me/enrolments");
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success) Fail(result.Error);
        return View(result.Data ?? new List<EnrolmentDto>());
    }

    [HttpPost]
    public async Task<IActionResult> Cancel(int id)
    {
        var result = await _api.DeleteAsync($"api/enrolments/{id}");
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success("Your enrolment has been cancelled."); else Fail(result.Error);
        return RedirectToAction(nameof(Index));
    }
}
