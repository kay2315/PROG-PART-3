using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[AllowAnonymous]
public class AccountController : AppController
{
    private readonly ApiClient _api;
    public AccountController(ApiClient api) => _api = api;

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (HttpContext.Session.GetCurrentUser() is { } user) return HomeFor(user.Role);
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var (result, cookie) = await _api.LoginAsync(model.Email, model.Password);
        if (!result.Success || result.Data is null || cookie is null)
        {
            ModelState.AddModelError("", result.Error);
            model.Password = "";
            return View(model);
        }
        HttpContext.Session.SignIn(result.Data.User, cookie);
        Success($"Welcome back, {result.Data.User.FirstName}!");
        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl) && model.ReturnUrl != "/")
            return LocalRedirect(model.ReturnUrl);
        return HomeFor(result.Data.User.Role);
    }

    [HttpGet]
    public IActionResult Register()
    {
        if (HttpContext.Session.GetCurrentUser() is { } user) return HomeFor(user.Role);
        return View(new RegisterViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var created = await _api.RegisterAsync(new RegisterRequest(model.FirstName.Trim(), model.LastName.Trim(), model.Email.Trim(), model.Password, model.Role));
        if (!created.Success)
        {
            ModelState.AddModelError("", created.Error);
            return View(model);
        }
        var (login, cookie) = await _api.LoginAsync(model.Email.Trim(), model.Password);
        if (!login.Success || login.Data is null || cookie is null)
        {
            Success("Your account was created. Please log in.");
            return RedirectToAction(nameof(Login));
        }
        HttpContext.Session.SignIn(login.Data.User, cookie);
        Success($"Welcome to RaceDay, {login.Data.User.FirstName}!");
        return HomeFor(login.Data.User.Role);
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        if (HttpContext.Session.GetCurrentUser() is not null) await _api.LogoutAsync();
        HttpContext.Session.Clear();
        Success("You have been logged out.");
        return RedirectToAction(nameof(Login));
    }
}
