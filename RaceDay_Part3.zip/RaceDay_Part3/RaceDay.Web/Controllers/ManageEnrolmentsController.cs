using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[RoleRequired("Organiser")]
public class ManageEnrolmentsController : AppController
{
    private readonly ApiClient _api;
    public ManageEnrolmentsController(ApiClient api) => _api = api;

    // id = event id
    public async Task<IActionResult> Index(int id, int? categoryId)
    {
        var ev = await _api.GetAsync<EventDto>($"api/events/{id}");
        if (Guard(ev) is { } redirect) return redirect;
        if (!ev.Success || ev.Data is null) return NotFound();
        if (ev.Data.OrganiserId != CurrentUser.UserId)
        {
            Fail("You can only view enrolments for events that you created.");
            return RedirectToAction("Index", "ManageEvents");
        }

        var list = await _api.GetAsync<List<EnrolmentDto>>($"api/events/{id}/enrolments");
        if (Guard(list) is { } expired) return expired;
        if (!list.Success) Fail(list.Error);

        var items = list.Data ?? new List<EnrolmentDto>();
        if (categoryId is not null) items = items.Where(x => x.CategoryId == categoryId).ToList();
        return View(new EnrolmentsViewModel { Event = ev.Data, Enrolments = items, CategoryId = categoryId });
    }

    [HttpPost]
    public async Task<IActionResult> SetPayment(int enrolmentId, int eventId, string paymentStatus)
    {
        var result = await _api.PutAsync<EnrolmentDto>($"api/enrolments/{enrolmentId}", new EnrolmentUpdateRequest(paymentStatus, null));
        if (Guard(result) is { } redirect) return redirect;
        if (result.Success) Success(paymentStatus == "Paid" ? "Payment confirmed - the enrolment is now Confirmed." : "Payment status updated.");
        else Fail(result.Error);
        return RedirectToAction(nameof(Index), new { id = eventId });
    }
}
