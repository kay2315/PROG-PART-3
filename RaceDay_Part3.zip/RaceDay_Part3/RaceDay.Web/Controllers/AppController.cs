using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public abstract class AppController : Controller
{
    protected SessionUser CurrentUser => HttpContext.Session.GetCurrentUser()!;

    protected void Success(string message) => TempData["Success"] = message;
    protected void Fail(string message) => TempData["Error"] = message;

    /// <summary>If the API says the session has expired, send the user back to the login page.</summary>
    protected IActionResult? Guard<T>(ApiResult<T> result)
    {
        if (!result.Unauthorized) return null;
        Fail("Your session has expired. Please log in again.");
        return RedirectToAction("Login", "Account");
    }

    protected IActionResult HomeFor(string role) =>
        role == "Organiser" ? RedirectToAction("Dashboard", "Organiser") : RedirectToAction("Index", "Home");

    protected string ModelErrors() =>
        string.Join(" ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).Where(m => !string.IsNullOrWhiteSpace(m)).Distinct());
}
