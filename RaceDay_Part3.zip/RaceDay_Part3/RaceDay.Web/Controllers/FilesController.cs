using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Helpers;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>Serves banners and profile pictures. The bytes come from the API (which reads Azure Blob Storage); the MVC app never talks to Azure.</summary>
public class FilesController : AppController
{
    private readonly ApiClient _api;
    public FilesController(ApiClient api) => _api = api;

    [HttpGet]
    public async Task<IActionResult> Image(string? path)
    {
        if (!UiFormat.IsSafeImagePath(path)) return NotFound();
        var file = await _api.GetFileAsync($"api/files/{path}");
        if (!file.Success || file.Data is null) return NotFound();
        Response.Headers.CacheControl = "private, max-age=86400";
        return File(file.Data.Bytes, file.Data.ContentType);
    }
}
