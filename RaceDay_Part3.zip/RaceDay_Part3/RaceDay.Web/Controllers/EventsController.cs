using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class EventsController : AppController
{
    private readonly ApiClient _api;
    public EventsController(ApiClient api) => _api = api;

    /// <summary>Full event information, banner and categories (available to both roles; only participants can enrol).</summary>
    public async Task<IActionResult> Details(int id)
    {
        var ev = await _api.GetAsync<EventDto>($"api/events/{id}");
        if (Guard(ev) is { } redirect) return redirect;
        if (!ev.Success || ev.Data is null) return NotFound();

        var model = new EventDetailsViewModel
        {
            Event = ev.Data,
            IsParticipant = CurrentUser.IsParticipant,
            IsOwner = CurrentUser.IsOrganiser && ev.Data.OrganiserId == CurrentUser.UserId
        };

        var results = await _api.GetAsync<List<EventResultDto>>($"api/events/{id}/results");
        if (results.Success && results.Data is not null) model.Results = results.Data;

        if (CurrentUser.IsParticipant)
        {
            var mine = await _api.GetAsync<List<EnrolmentDto>>("api/users/me/enrolments");
            if (Guard(mine) is { } expired) return expired;
            if (mine.Success && mine.Data is not null)
                model.EnrolledCategoryIds = mine.Data.Where(x => x.EventId == id && x.EnrolmentStatus != "Cancelled").Select(x => x.CategoryId).ToHashSet();
        }
        return View(model);
    }

    [HttpPost, RoleRequired("Participant")]
    public async Task<IActionResult> Enrol(int id, int categoryId)
    {
        if (categoryId <= 0)
        {
            Fail("Please choose a category before enrolling.");
            return RedirectToAction(nameof(Details), new { id });
        }
        var result = await _api.PostAsync<EnrolmentDto>($"api/events/{id}/enrolments", new EnrolmentRequest(categoryId));
        if (Guard(result) is { } redirect) return redirect;
        if (!result.Success)
        {
            Fail(result.Error);
            return RedirectToAction(nameof(Details), new { id });
        }
        Success($"You are enrolled in {result.Data?.EventName} ({result.Data?.CategoryName}). Your enrolment is pending until payment is confirmed.");
        return RedirectToAction("Index", "MyEnrolments");
    }
}
