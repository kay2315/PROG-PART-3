/*
    RaceDay - Part 1
    Section C: SQL Server Database Script
    Designed for SQL Server / SSMS.

    Data model:
    Users -> UserProfiles (1:1)
    Users -> Events (1:M, organiser)
    Events -> Categories (1:M)
    Users <-> Events through Enrolments (M:N)
    Enrolments -> Results (1:0..1)
*/

IF DB_ID(N'RaceDay') IS NULL
BEGIN
    CREATE DATABASE RaceDay;
END;
GO

USE RaceDay;
GO

-- Drop tables in dependency order so the script can be rerun.
IF OBJECT_ID(N'dbo.Results', N'U') IS NOT NULL DROP TABLE dbo.Results;
IF OBJECT_ID(N'dbo.Enrolments', N'U') IS NOT NULL DROP TABLE dbo.Enrolments;
IF OBJECT_ID(N'dbo.Categories', N'U') IS NOT NULL DROP TABLE dbo.Categories;
IF OBJECT_ID(N'dbo.Events', N'U') IS NOT NULL DROP TABLE dbo.Events;
IF OBJECT_ID(N'dbo.UserProfiles', N'U') IS NOT NULL DROP TABLE dbo.UserProfiles;
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL DROP TABLE dbo.Users;
GO

CREATE TABLE dbo.Users
(
    UserId INT IDENTITY(1,1) NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(255) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Role NVARCHAR(20) NOT NULL
        CONSTRAINT CK_Users_Role CHECK (Role IN (N'Organiser', N'Participant')),
    CreatedAt DATETIME2(0) NOT NULL
        CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_Users PRIMARY KEY (UserId),
    CONSTRAINT UQ_Users_Email UNIQUE (Email)
);
GO

CREATE TABLE dbo.UserProfiles
(
    UserProfileId INT IDENTITY(1,1) NOT NULL,
    UserId INT NOT NULL,
    Phone NVARCHAR(30) NULL,
    DateOfBirth DATE NULL,
    EmergencyContactName NVARCHAR(100) NULL,
    EmergencyContactPhone NVARCHAR(30) NULL,
    City NVARCHAR(100) NULL,
    Province NVARCHAR(100) NULL,

    CONSTRAINT PK_UserProfiles PRIMARY KEY (UserProfileId),
    CONSTRAINT UQ_UserProfiles_UserId UNIQUE (UserId),
    CONSTRAINT FK_UserProfiles_Users
        FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId)
);
GO

CREATE TABLE dbo.Events
(
    EventId INT IDENTITY(1,1) NOT NULL,
    OrganiserId INT NOT NULL,
    EventName NVARCHAR(150) NOT NULL,
    EventType NVARCHAR(20) NOT NULL
        CONSTRAINT CK_Events_EventType CHECK (EventType IN (N'Running', N'Walking', N'Cycling')),
    Description NVARCHAR(1000) NULL,
    EventDate DATE NOT NULL,
    StartTime TIME(0) NOT NULL,
    Venue NVARCHAR(200) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    Province NVARCHAR(100) NOT NULL,
    Status NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Events_Status DEFAULT N'Upcoming'
        CONSTRAINT CK_Events_Status CHECK (Status IN (N'Upcoming', N'Open', N'Closed', N'Completed', N'Cancelled')),
    CreatedAt DATETIME2(0) NOT NULL
        CONSTRAINT DF_Events_CreatedAt DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_Events PRIMARY KEY (EventId),
    CONSTRAINT FK_Events_Organiser
        FOREIGN KEY (OrganiserId) REFERENCES dbo.Users(UserId)
);
GO

CREATE TABLE dbo.Categories
(
    CategoryId INT IDENTITY(1,1) NOT NULL,
    EventId INT NOT NULL,
    CategoryName NVARCHAR(100) NOT NULL,
    DistanceKm DECIMAL(6,2) NOT NULL,
    EntryFee DECIMAL(10,2) NOT NULL
        CONSTRAINT DF_Categories_EntryFee DEFAULT (0),
    MaximumParticipants INT NULL,

    CONSTRAINT PK_Categories PRIMARY KEY (CategoryId),
    CONSTRAINT UQ_Categories_Event_Category UNIQUE (EventId, CategoryName),
    CONSTRAINT CK_Categories_Distance CHECK (DistanceKm > 0),
    CONSTRAINT CK_Categories_EntryFee CHECK (EntryFee >= 0),
    CONSTRAINT CK_Categories_MaxParticipants CHECK (MaximumParticipants IS NULL OR MaximumParticipants > 0),
    CONSTRAINT FK_Categories_Events
        FOREIGN KEY (EventId) REFERENCES dbo.Events(EventId)
);
GO

CREATE TABLE dbo.Enrolments
(
    EnrolmentId INT IDENTITY(1,1) NOT NULL,
    ParticipantId INT NOT NULL,
    CategoryId INT NOT NULL,
    EnrolmentDate DATETIME2(0) NOT NULL
        CONSTRAINT DF_Enrolments_EnrolmentDate DEFAULT SYSUTCDATETIME(),
    RaceNumber NVARCHAR(20) NULL,
    PaymentStatus NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Enrolments_PaymentStatus DEFAULT N'Pending'
        CONSTRAINT CK_Enrolments_PaymentStatus CHECK (PaymentStatus IN (N'Pending', N'Paid', N'Refunded', N'Waived')),
    EnrolmentStatus NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Enrolments_EnrolmentStatus DEFAULT N'Active'
        CONSTRAINT CK_Enrolments_EnrolmentStatus CHECK (EnrolmentStatus IN (N'Active', N'Cancelled', N'Completed')),

    CONSTRAINT PK_Enrolments PRIMARY KEY (EnrolmentId),
    CONSTRAINT UQ_Enrolments_Participant_Category UNIQUE (ParticipantId, CategoryId),
    CONSTRAINT UQ_Enrolments_RaceNumber UNIQUE (RaceNumber),
    CONSTRAINT FK_Enrolments_Participant
        FOREIGN KEY (ParticipantId) REFERENCES dbo.Users(UserId),
    CONSTRAINT FK_Enrolments_Category
        FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(CategoryId)
);
GO

CREATE TABLE dbo.Results
(
    ResultId INT IDENTITY(1,1) NOT NULL,
    EnrolmentId INT NOT NULL,
    FinishPosition INT NULL,
    FinishTimeSeconds INT NULL,
    ResultStatus NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Results_ResultStatus DEFAULT N'Finished'
        CONSTRAINT CK_Results_ResultStatus CHECK (ResultStatus IN (N'Finished', N'DNF', N'DNS', N'DSQ')),
    RecordedAt DATETIME2(0) NOT NULL
        CONSTRAINT DF_Results_RecordedAt DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_Results PRIMARY KEY (ResultId),
    CONSTRAINT UQ_Results_Enrolment UNIQUE (EnrolmentId),
    CONSTRAINT CK_Results_FinishPosition CHECK (FinishPosition IS NULL OR FinishPosition > 0),
    CONSTRAINT CK_Results_FinishTime CHECK (FinishTimeSeconds IS NULL OR FinishTimeSeconds > 0),
    CONSTRAINT FK_Results_Enrolment
        FOREIGN KEY (EnrolmentId) REFERENCES dbo.Enrolments(EnrolmentId)
);
GO

-- Sample users: 2 organisers and 2 participants.
INSERT INTO dbo.Users (FirstName, LastName, Email, PasswordHash, Role)
VALUES
(N'Lerato', N'Mokoena', N'lerato.mokoena@raceday.example', N'REPLACE_WITH_REAL_PASSWORD_HASH', N'Organiser'),
(N'Johan', N'van der Merwe', N'johan.vdm@raceday.example', N'REPLACE_WITH_REAL_PASSWORD_HASH', N'Organiser'),
(N'Anele', N'Ndlovu', N'anele.ndlovu@raceday.example', N'REPLACE_WITH_REAL_PASSWORD_HASH', N'Participant'),
(N'Ryan', N'Jacobs', N'ryan.jacobs@raceday.example', N'REPLACE_WITH_REAL_PASSWORD_HASH', N'Participant');
GO

INSERT INTO dbo.UserProfiles
    (UserId, Phone, DateOfBirth, EmergencyContactName, EmergencyContactPhone, City, Province)
VALUES
(1, N'0825550101', '1988-04-15', N'Thabo Mokoena', N'0835550101', N'Johannesburg', N'Gauteng'),
(2, N'0825550102', '1985-09-21', N'Maria van der Merwe', N'0845550102', N'Cape Town', N'Western Cape'),
(3, N'0825550103', '1996-02-11', N'Nomsa Ndlovu', N'0855550103', N'Durban', N'KwaZulu-Natal'),
(4, N'0825550104', '1993-07-08', N'Peter Jacobs', N'0865550104', N'Pretoria', N'Gauteng');
GO

-- Sample events: 3 events, covering running, cycling and walking.
INSERT INTO dbo.Events
    (OrganiserId, EventName, EventType, Description, EventDate, StartTime, Venue, City, Province, Status)
VALUES
(1, N'Johannesburg Spring Run', N'Running',
 N'A community road-running event through central Johannesburg.', '2026-10-18', '06:30',
 N'Zoo Lake Sports Grounds', N'Johannesburg', N'Gauteng', N'Open'),
(2, N'Cape Winelands Cycle Tour', N'Cycling',
 N'A road cycling event through the Cape Winelands.', '2026-11-08', '06:00',
 N'Stellenbosch Civic Centre', N'Stellenbosch', N'Western Cape', N'Open'),
(1, N'Durban Beach Walk', N'Walking',
 N'A family-friendly coastal walking event along the Durban beachfront.', '2026-11-22', '07:00',
 N'Moses Mabhida Stadium', N'Durban', N'KwaZulu-Natal', N'Upcoming');
GO

-- Categories for each event.
INSERT INTO dbo.Categories (EventId, CategoryName, DistanceKm, EntryFee, MaximumParticipants)
VALUES
(1, N'10 km Run', 10.00, 180.00, 1500),
(1, N'21.1 km Half Marathon', 21.10, 250.00, 1000),
(2, N'60 km Cycle', 60.00, 320.00, 1200),
(2, N'110 km Cycle', 110.00, 450.00, 800),
(3, N'5 km Family Walk', 5.00, 100.00, 1000),
(3, N'10 km Beach Walk', 10.00, 150.00, 800);
GO

-- Sample enrolments.
INSERT INTO dbo.Enrolments
    (ParticipantId, CategoryId, EnrolmentDate, RaceNumber, PaymentStatus, EnrolmentStatus)
VALUES
(3, 1, '2026-09-02T09:15:00', N'JR-1001', N'Paid', N'Active'),
(4, 2, '2026-09-03T10:30:00', N'JR-1002', N'Paid', N'Active'),
(3, 3, '2026-09-04T12:00:00', N'CT-2001', N'Paid', N'Active'),
(4, 5, '2026-09-05T14:20:00', N'DW-3001', N'Paid', N'Active');
GO

-- Sample results for completed/recorded participation.
INSERT INTO dbo.Results
    (EnrolmentId, FinishPosition, FinishTimeSeconds, ResultStatus)
VALUES
(1, 12, 2940, N'Finished'),
(2, 7, 5670, N'Finished');
GO

-- Verification queries.
SELECT * FROM dbo.Users;
SELECT * FROM dbo.UserProfiles;
SELECT * FROM dbo.Events;
SELECT * FROM dbo.Categories;
SELECT * FROM dbo.Enrolments;
SELECT * FROM dbo.Results;
GO
