# RaceDay – Part 1 API Endpoint Plan

## Purpose
This endpoint plan defines the RESTful API that will be implemented in Part 2. The routes are designed around the RaceDay data model and the required roles: **Organiser** and **Participant**.

## Roles
- **Public:** no authentication required.
- **Logged in:** any authenticated user.
- **Participant:** authenticated user whose `Users.Role` is `Participant`.
- **Organiser:** authenticated user whose `Users.Role` is `Organiser`.

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
|POST|/api/auth/register|Creates a new participant account.|Public|{ firstName, lastName, email, password }|201 Created; 400 Bad Request if validation fails; 409 Conflict if email exists.|
|POST|/api/auth/login|Authenticates a user and returns an access token.|Public|{ email, password }|200 OK { token, user }; 401 Unauthorized for invalid credentials.|
|GET|/api/users/me|Returns the authenticated user's profile.|Logged in|None|200 OK { user, profile }; 401 Unauthorized.|
|PUT|/api/users/me|Updates the authenticated user's profile.|Logged in|{ firstName, lastName, phone, dateOfBirth, emergencyContactName, emergencyContactPhone, city, province }|200 OK updated profile; 400 Bad Request; 401 Unauthorized.|
|GET|/api/users/{id}|Returns a public user profile by ID.|Logged in|None|200 OK profile; 404 Not Found.|
|GET|/api/events|Lists upcoming events with optional filters.|Public|None; query parameters may include eventType, city, province, dateFrom, dateTo.|200 OK array of events.|
|GET|/api/events/{id}|Returns details for one event, including categories.|Public|None|200 OK event details; 404 Not Found.|
|POST|/api/events|Creates a new event.|Organiser|{ eventName, eventType, description, eventDate, startTime, venue, city, province, status }|201 Created event; 400 Bad Request; 401/403 Unauthorized/Forbidden.|
|PUT|/api/events/{id}|Updates an event owned by the organiser.|Organiser|{ eventName, eventType, description, eventDate, startTime, venue, city, province, status }|200 OK updated event; 403 Forbidden; 404 Not Found.|
|DELETE|/api/events/{id}|Cancels/removes an event owned by the organiser.|Organiser|None|204 No Content; 403 Forbidden; 404 Not Found.|
|GET|/api/events/{eventId}/categories|Lists all categories for an event.|Public|None|200 OK array of categories; 404 Not Found.|
|POST|/api/events/{eventId}/categories|Adds a category to an event.|Organiser|{ categoryName, distanceKm, entryFee, maximumParticipants }|201 Created category; 400 Bad Request; 403 Forbidden.|
|PUT|/api/categories/{id}|Updates an event category.|Organiser|{ categoryName, distanceKm, entryFee, maximumParticipants }|200 OK updated category; 403 Forbidden; 404 Not Found.|
|DELETE|/api/categories/{id}|Removes an event category when allowed.|Organiser|None|204 No Content; 409 Conflict if enrolments exist; 403 Forbidden; 404 Not Found.|
|POST|/api/events/{eventId}/enrolments|Enrols the authenticated participant in an event category.|Participant|{ categoryId }|201 Created enrolment; 400 Bad Request; 409 Conflict if already enrolled/full.|
|GET|/api/users/me/enrolments|Lists the authenticated participant's enrolments.|Participant|None|200 OK array of enrolments; 401 Unauthorized.|
|GET|/api/events/{eventId}/enrolments|Lists enrolments for an event.|Organiser|None|200 OK array of enrolments; 403 Forbidden; 404 Not Found.|
|PUT|/api/enrolments/{id}|Updates enrolment/payment status where permitted.|Participant or Organiser|{ paymentStatus?, enrolmentStatus? }|200 OK updated enrolment; 403 Forbidden; 404 Not Found.|
|DELETE|/api/enrolments/{id}|Cancels the authenticated participant's enrolment.|Participant|None|204 No Content; 403 Forbidden; 404 Not Found.|
|GET|/api/events/{eventId}/results|Returns published results for an event.|Public|None|200 OK array of results; 404 Not Found.|
|POST|/api/events/{eventId}/results|Records a result for an enrolment.|Organiser|{ enrolmentId, finishPosition, finishTimeSeconds, resultStatus }|201 Created result; 400 Bad Request; 403 Forbidden; 404 Not Found.|
|PUT|/api/results/{id}|Corrects or updates a recorded result.|Organiser|{ finishPosition?, finishTimeSeconds?, resultStatus }|200 OK updated result; 403 Forbidden; 404 Not Found.|
|DELETE|/api/results/{id}|Deletes an incorrectly recorded result.|Organiser|None|204 No Content; 403 Forbidden; 404 Not Found.|
|GET|/api/users/me/results|Returns the authenticated participant's personal performance history.|Participant|None|200 OK array of results; 401 Unauthorized.|
|GET|/api/events/{eventId}/weather|Returns live weather information for race-day preparation.|Public|None|200 OK weather forecast; 404 Not Found; 502 Bad Gateway if weather provider fails.|
|GET|/api/events/{eventId}/route|Returns route information for race-day preparation.|Public|None|200 OK route summary/map data; 404 Not Found.|

## API Design Notes
1. All application routes use the `/api/` prefix.
2. Authentication uses a bearer access token returned by the login endpoint.
3. Organiser ownership must be checked before modifying an event, category, enrolment list, or result.
4. Participants may only create/cancel their own enrolments and view their own performance history.
5. HTTP status codes follow standard REST conventions: `200`, `201`, `204`, `400`, `401`, `403`, `404`, `409`, and `502` where appropriate.
6. The weather and route endpoints support the race-day preparation functionality described in the brief.
