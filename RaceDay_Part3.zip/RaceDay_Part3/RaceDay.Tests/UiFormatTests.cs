using RaceDay.Web.Helpers;
using Xunit;

namespace RaceDay.Tests;

public class UiFormatTests
{
    [Fact] public void Duration_FormatsHoursMinutesSeconds() => Assert.Equal("1:02:05", UiFormat.Duration(3725));
    [Fact] public void Duration_HandlesMissingTime() => Assert.Equal("—", UiFormat.Duration(null));

    [Theory]
    [InlineData(1, "1st")] [InlineData(2, "2nd")] [InlineData(3, "3rd")] [InlineData(4, "4th")]
    [InlineData(11, "11th")] [InlineData(12, "12th")] [InlineData(13, "13th")]
    [InlineData(21, "21st")] [InlineData(47, "47th")] [InlineData(101, "101st")] [InlineData(111, "111th")]
    public void Ordinal_UsesCorrectSuffix(int n, string expected) => Assert.Equal(expected, UiFormat.Ordinal(n));

    [Fact]
    public void PositionText_ShowsPositionOutOfFinishers() =>
        Assert.Equal("47th out of 312 finishers", UiFormat.PositionText(47, 312, "Finished"));

    [Fact]
    public void PositionText_ShowsStatusForNonFinishers() =>
        Assert.Equal("Did not finish", UiFormat.PositionText(null, 0, "DNF"));

    [Theory]
    [InlineData("Confirmed", "status-confirmed")]
    [InlineData("Pending", "status-pending")]
    [InlineData("Cancelled", "status-cancelled")]
    [InlineData("Completed", "status-completed")]
    public void EnrolmentBadgeClass_ColourCodesStatuses(string status, string css) => Assert.Equal(css, UiFormat.EnrolmentBadgeClass(status));

    [Fact] public void ToSeconds_CombinesParts() => Assert.Equal(3723, UiFormat.ToSeconds(1, 2, 3));

    [Fact]
    public void ImageSrc_RoutesThroughMvcProxy() =>
        Assert.Equal("/Files/Image?path=banners%2Fabc123.jpg", UiFormat.ImageSrc("/api/files/banners/abc123.jpg"));

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("/api/files/../secrets.txt")]
    [InlineData("https://evil.example/x.jpg")]
    public void ImageSrc_RejectsUnsafeValues(string? url) => Assert.Null(UiFormat.ImageSrc(url));

    [Fact]
    public void DateParsing_AcceptsIsoDatesOnly()
    {
        Assert.True(UiFormat.TryParseDate("2026-11-30", out var d));
        Assert.Equal(new DateOnly(2026, 11, 30), d);
        Assert.False(UiFormat.TryParseDate("30/11/2026", out _));
        Assert.False(UiFormat.TryParseDate("", out _));
    }

    [Fact]
    public void TimeParsing_AcceptsBrowserTimeValues()
    {
        Assert.True(UiFormat.TryParseTime("06:30", out var t));
        Assert.Equal(new TimeOnly(6, 30), t);
        Assert.False(UiFormat.TryParseTime("25:99", out _));
    }
}
