using RaceDay.Api;
using Xunit;

namespace RaceDay.Tests;

public class ImageRulesTests
{
    [Fact] public void AcceptsSmallPng() => Assert.Null(ImageRules.Validate("banner.png", "image/png", 1024));
    [Fact] public void RejectsEmptyFile() => Assert.NotNull(ImageRules.Validate("banner.png", "image/png", 0));
    [Fact] public void RejectsOversizedFile() => Assert.NotNull(ImageRules.Validate("banner.png", "image/png", ImageRules.MaxBytes + 1));
    [Fact] public void RejectsNonImageExtension() => Assert.NotNull(ImageRules.Validate("malware.exe", "image/png", 1024));
    [Fact] public void RejectsNonImageContentType() => Assert.NotNull(ImageRules.Validate("banner.png", "text/html", 1024));

    [Theory]
    [InlineData("banners/0123456789abcdef.jpg", true)]
    [InlineData("profiles/ABC123.png", true)]
    [InlineData("banners/../appsettings.json", false)]
    [InlineData("other/file.jpg", false)]
    [InlineData("banners/a/b.jpg", false)]
    [InlineData(null, false)]
    public void BlobNameSafety(string? name, bool expected) => Assert.Equal(expected, ImageRules.IsSafeBlobName(name));
}

public class MapperTests
{
    [Theory]
    [InlineData("Active", "Paid", "Confirmed")]
    [InlineData("Active", "Waived", "Confirmed")]
    [InlineData("Active", "Pending", "Pending")]
    [InlineData("Cancelled", "Paid", "Cancelled")]
    [InlineData("Completed", "Paid", "Completed")]
    public void DisplayStatus_MapsEnrolmentAndPayment(string enrolment, string payment, string expected) =>
        Assert.Equal(expected, Mapper.DisplayStatus(enrolment, payment));

    [Fact] public void FileUrl_PrefixesApiRoute() => Assert.Equal("/api/files/banners/a.jpg", Mapper.FileUrl("banners/a.jpg"));
    [Fact] public void FileUrl_NullStaysNull() => Assert.Null(Mapper.FileUrl(null));

    [Fact]
    public void CategoryDto_CountsOnlyNonCancelledEnrolments()
    {
        var category = new RaceCategory { CategoryId = 1, EventId = 1, CategoryName = "10K", DistanceKm = 10, MaximumParticipants = 50 };
        category.Enrolments.Add(new Enrolment { EnrolmentStatus = "Active" });
        category.Enrolments.Add(new Enrolment { EnrolmentStatus = "Completed" });
        category.Enrolments.Add(new Enrolment { EnrolmentStatus = "Cancelled" });
        Assert.Equal(2, category.ToDto().EnrolledCount);
    }

    [Fact]
    public void UserDto_NeverExposesPasswordHash()
    {
        var dto = new AppUser { UserId = 1, FirstName = "A", LastName = "B", Email = "a@b.co", Role = "Participant", PasswordHash = "secret" }.ToDto();
        Assert.DoesNotContain("secret", System.Text.Json.JsonSerializer.Serialize(dto));
    }
}

public class LocalFileStorageTests
{
    [Fact]
    public async Task SaveReadDelete_RoundTrips()
    {
        var root = Path.Combine(Path.GetTempPath(), "raceday-tests-" + Guid.NewGuid().ToString("N"));
        try
        {
            var storage = new LocalFileStorage(root);
            var name = await storage.SaveAsync("banners", "pic.PNG", new MemoryStream(new byte[] { 1, 2, 3 }), "image/png");
            Assert.True(ImageRules.IsSafeBlobName(name));
            var read = await storage.OpenReadAsync(name);
            Assert.NotNull(read);
            await using (read!.Value.Content) Assert.Equal("image/png", read.Value.ContentType);
            await storage.DeleteAsync(name);
            Assert.Null(await storage.OpenReadAsync(name));
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }
}
