using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace RaceDay.Api;

/// <summary>Creates the schema on start-up (waiting for SQL Server in Docker) and optionally seeds demo data.</summary>
public static class DbInitializer
{
    public static async Task InitialiseAsync(IServiceProvider services, IConfiguration config, ILogger logger)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<RaceDayContext>();

        for (var attempt = 1; ; attempt++)
        {
            try
            {
                await db.Database.EnsureCreatedAsync();
                await PatchSchemaAsync(db);
                break;
            }
            catch (Exception ex) when (attempt < 30)
            {
                logger.LogWarning("Database not ready (attempt {Attempt}/30): {Message}", attempt, ex.Message);
                await Task.Delay(TimeSpan.FromSeconds(2));
            }
        }

        if (config.GetValue<bool>("Seed:DemoData")) await SeedAsync(db, logger);
    }

    // Adds the Part 3 columns when the database was created by Part 2 (EnsureCreated never alters existing tables).
    private static async Task PatchSchemaAsync(RaceDayContext db)
    {
        await db.Database.ExecuteSqlRawAsync("IF COL_LENGTH('dbo.Events','BannerBlobName') IS NULL ALTER TABLE dbo.Events ADD BannerBlobName NVARCHAR(300) NULL;");
        await db.Database.ExecuteSqlRawAsync("IF COL_LENGTH('dbo.Events','DistanceKm') IS NULL ALTER TABLE dbo.Events ADD DistanceKm DECIMAL(6,2) NULL;");
        await db.Database.ExecuteSqlRawAsync("IF COL_LENGTH('dbo.UserProfiles','ProfilePictureBlobName') IS NULL ALTER TABLE dbo.UserProfiles ADD ProfilePictureBlobName NVARCHAR(300) NULL;");
    }

    private static async Task SeedAsync(RaceDayContext db, ILogger logger)
    {
        if (await db.Users.AnyAsync()) return;
        var hasher = new PasswordHasher<AppUser>();
        AppUser NewUser(string first, string last, string email, string role)
        {
            var u = new AppUser { FirstName = first, LastName = last, Email = email, Role = role, Profile = new UserProfile { City = "Pretoria", Province = "Gauteng" } };
            u.PasswordHash = hasher.HashPassword(u, "Password123!");
            return u;
        }

        var organiser = NewUser("Olivia", "Organiser", "organiser@raceday.test", "Organiser");
        var participant = NewUser("Pieter", "Participant", "participant@raceday.test", "Participant");
        var rival1 = NewUser("Thandi", "Nkosi", "thandi@raceday.test", "Participant");
        var rival2 = NewUser("Sam", "Jacobs", "sam@raceday.test", "Participant");
        db.Users.AddRange(organiser, participant, rival1, rival2);
        await db.SaveChangesAsync();

        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var upcoming = new RaceEvent
        {
            OrganiserId = organiser.UserId, EventName = "Pretoria Sunrise 10K", EventType = "Running",
            Description = "A fast, flat route through the Pretoria CBD finishing at the Union Buildings gardens.",
            EventDate = today.AddDays(21), StartTime = new TimeOnly(6, 30), Venue = "Union Buildings Gardens", City = "Pretoria", Province = "Gauteng",
            Status = "Open", DistanceKm = 10,
            Categories =
            {
                new RaceCategory { CategoryName = "10K Open", DistanceKm = 10, EntryFee = 150, MaximumParticipants = 500 },
                new RaceCategory { CategoryName = "5K Fun Run", DistanceKm = 5, EntryFee = 90, MaximumParticipants = 300 },
                new RaceCategory { CategoryName = "Under 18 (5K)", DistanceKm = 5, EntryFee = 60, MaximumParticipants = 100 }
            }
        };
        var ride = new RaceEvent
        {
            OrganiserId = organiser.UserId, EventName = "Magaliesberg Mountain Ride", EventType = "Cycling",
            Description = "A scenic 60 km road ride through the Magaliesberg foothills.",
            EventDate = today.AddDays(45), StartTime = new TimeOnly(7, 0), Venue = "Hartbeespoort Dam Wall", City = "Hartbeespoort", Province = "North West",
            Status = "Open", DistanceKm = 60,
            Categories = { new RaceCategory { CategoryName = "60 km Road", DistanceKm = 60, EntryFee = 250, MaximumParticipants = 400 } }
        };
        var past = new RaceEvent
        {
            OrganiserId = organiser.UserId, EventName = "Heritage Day 5K", EventType = "Running",
            Description = "A community 5K held on Heritage Day.",
            EventDate = today.AddDays(-14), StartTime = new TimeOnly(8, 0), Venue = "Magnolia Dell", City = "Pretoria", Province = "Gauteng",
            Status = "Completed", DistanceKm = 5,
            Categories = { new RaceCategory { CategoryName = "5K Open", DistanceKm = 5, EntryFee = 80, MaximumParticipants = 200 } }
        };
        db.Events.AddRange(upcoming, ride, past);
        await db.SaveChangesAsync();

        var pastCategory = past.Categories.First();
        var runs = new[] { (rival1, 1, 1385), (rival2, 2, 1442), (participant, 3, 1511) };
        foreach (var (user, position, seconds) in runs)
        {
            db.Enrolments.Add(new Enrolment
            {
                ParticipantId = user.UserId, CategoryId = pastCategory.CategoryId, PaymentStatus = "Paid", EnrolmentStatus = "Completed",
                RaceNumber = (100 + position).ToString(),
                Result = new RaceResult { FinishPosition = position, FinishTimeSeconds = seconds, ResultStatus = "Finished" }
            });
        }
        db.Enrolments.Add(new Enrolment { ParticipantId = participant.UserId, CategoryId = upcoming.Categories.First().CategoryId, PaymentStatus = "Pending", EnrolmentStatus = "Active" });
        await db.SaveChangesAsync();
        logger.LogInformation("Demo data seeded (organiser@raceday.test / participant@raceday.test, password Password123!).");
    }
}
