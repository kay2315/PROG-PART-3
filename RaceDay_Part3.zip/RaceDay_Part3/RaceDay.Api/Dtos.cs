namespace RaceDay.Api;

// Response shapes returned by the API. Entities are never serialised directly so that
// password hashes and circular references can never leak to a client.

public record ProfileDto(string? Phone, DateOnly? DateOfBirth, string? EmergencyContactName, string? EmergencyContactPhone, string? City, string? Province, string? ProfilePictureUrl);
public record UserDto(int UserId, string FirstName, string LastName, string Email, string Role, ProfileDto? Profile);
public record CategoryDto(int CategoryId, int EventId, string CategoryName, decimal DistanceKm, decimal EntryFee, int? MaximumParticipants, int EnrolledCount);
public record EventDto(int EventId, int OrganiserId, string? OrganiserName, string EventName, string EventType, string? Description, DateOnly EventDate, TimeOnly StartTime, string Venue, string City, string Province, string Status, decimal? DistanceKm, string? BannerUrl, List<CategoryDto> Categories);
public record ResultDto(int ResultId, int EnrolmentId, int? FinishPosition, int? FinishTimeSeconds, string ResultStatus, DateTime RecordedAt);
public record EnrolmentDto(int EnrolmentId, int ParticipantId, string ParticipantName, string ParticipantEmail, int CategoryId, string CategoryName, decimal CategoryDistanceKm, int EventId, string EventName, string EventType, DateOnly EventDate, DateTime EnrolmentDate, string? RaceNumber, string PaymentStatus, string EnrolmentStatus, string DisplayStatus, ResultDto? Result);
public record EventResultDto(int ResultId, int EnrolmentId, string ParticipantName, string? RaceNumber, int CategoryId, string CategoryName, int? FinishPosition, int? FinishTimeSeconds, string ResultStatus);
public record MyResultDto(int ResultId, int EventId, string EventName, DateOnly EventDate, string CategoryName, decimal DistanceKm, int? FinishPosition, int? FinishTimeSeconds, string ResultStatus, int TotalFinishers);
public record DashboardEventDto(int EventId, string EventName, string EventType, DateOnly EventDate, string Status, int CategoryCount, int TotalEnrolments, int PendingPayments);
public record DashboardDto(int TotalEvents, int UpcomingEvents, int TotalEnrolments, int PendingPayments, List<DashboardEventDto> Events);

public static class Mapper
{
    public static string? FileUrl(string? blobName) => string.IsNullOrEmpty(blobName) ? null : "/api/files/" + blobName;

    /// <summary>Confirmed = active and paid/waived (green), Pending = active awaiting payment (amber).</summary>
    public static string DisplayStatus(string enrolmentStatus, string paymentStatus) => enrolmentStatus switch
    {
        "Cancelled" => "Cancelled",
        "Completed" => "Completed",
        _ => paymentStatus is "Paid" or "Waived" ? "Confirmed" : "Pending"
    };

    public static ProfileDto? ToDto(this UserProfile? p) => p is null ? null
        : new ProfileDto(p.Phone, p.DateOfBirth, p.EmergencyContactName, p.EmergencyContactPhone, p.City, p.Province, FileUrl(p.ProfilePictureBlobName));

    public static UserDto ToDto(this AppUser u) => new(u.UserId, u.FirstName, u.LastName, u.Email, u.Role, u.Profile.ToDto());

    public static CategoryDto ToDto(this RaceCategory c) => new(c.CategoryId, c.EventId, c.CategoryName, c.DistanceKm, c.EntryFee, c.MaximumParticipants,
        c.Enrolments.Count(x => x.EnrolmentStatus != "Cancelled"));

    public static CategoryDto ToDtoWithoutEnrolments(this RaceCategory c) => new(c.CategoryId, c.EventId, c.CategoryName, c.DistanceKm, c.EntryFee, c.MaximumParticipants, 0);

    public static EventDto ToDto(this RaceEvent e) => new(e.EventId, e.OrganiserId,
        e.Organiser is null ? null : $"{e.Organiser.FirstName} {e.Organiser.LastName}",
        e.EventName, e.EventType, e.Description, e.EventDate, e.StartTime, e.Venue, e.City, e.Province, e.Status, e.DistanceKm,
        FileUrl(e.BannerBlobName), e.Categories.OrderBy(c => c.DistanceKm).ThenBy(c => c.CategoryName).Select(c => c.ToDto()).ToList());

    public static ResultDto ToDto(this RaceResult r) => new(r.ResultId, r.EnrolmentId, r.FinishPosition, r.FinishTimeSeconds, r.ResultStatus, r.RecordedAt);

    public static EnrolmentDto ToDto(this Enrolment e)
    {
        var cat = e.Category;
        var ev = cat?.Event;
        return new EnrolmentDto(e.EnrolmentId, e.ParticipantId,
            e.Participant is null ? "" : $"{e.Participant.FirstName} {e.Participant.LastName}",
            e.Participant?.Email ?? "", e.CategoryId, cat?.CategoryName ?? "", cat?.DistanceKm ?? 0,
            ev?.EventId ?? 0, ev?.EventName ?? "", ev?.EventType ?? "", ev?.EventDate ?? default,
            e.EnrolmentDate, e.RaceNumber, e.PaymentStatus, e.EnrolmentStatus,
            DisplayStatus(e.EnrolmentStatus, e.PaymentStatus), e.Result?.ToDto());
    }
}
