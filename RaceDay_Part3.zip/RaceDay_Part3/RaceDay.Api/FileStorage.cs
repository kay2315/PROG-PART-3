using System.Text.RegularExpressions;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.Api;

/// <summary>Abstraction over file storage. Only the API ever talks to storage; the MVC app goes through the API.</summary>
public interface IFileStorage
{
    /// <summary>Stores the stream and returns the generated blob name (e.g. banners/3f2a...jpg).</summary>
    Task<string> SaveAsync(string folder, string originalFileName, Stream content, string contentType, CancellationToken ct = default);
    Task<(Stream Content, string ContentType)?> OpenReadAsync(string blobName, CancellationToken ct = default);
    Task DeleteAsync(string blobName, CancellationToken ct = default);
}

public static class ImageRules
{
    public const long MaxBytes = 5 * 1024 * 1024;
    private static readonly HashSet<string> AllowedExtensions = new(StringComparer.OrdinalIgnoreCase) { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
    private static readonly Regex SafeBlobName = new(@"^(banners|profiles)/[A-Za-z0-9]+\.[A-Za-z0-9]+$", RegexOptions.Compiled);

    /// <summary>Returns an error message, or null when the upload is acceptable.</summary>
    public static string? Validate(string? fileName, string? contentType, long length)
    {
        if (length <= 0) return "The uploaded file is empty.";
        if (length > MaxBytes) return "The image is too large. The maximum size is 5 MB.";
        var ext = Path.GetExtension(fileName ?? "");
        if (!AllowedExtensions.Contains(ext)) return "Only JPG, PNG, GIF or WEBP images are allowed.";
        if (contentType is null || !contentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase)) return "The uploaded file is not an image.";
        return null;
    }

    public static bool IsSafeBlobName(string? blobName) => blobName is not null && SafeBlobName.IsMatch(blobName);
}

public class AzureBlobFileStorage : IFileStorage
{
    private readonly BlobContainerClient _container;
    private bool _containerReady;

    public AzureBlobFileStorage(string connectionString, string containerName)
        => _container = new BlobContainerClient(connectionString, containerName);

    private async Task EnsureContainerAsync(CancellationToken ct)
    {
        if (_containerReady) return;
        await _container.CreateIfNotExistsAsync(PublicAccessType.None, cancellationToken: ct);
        _containerReady = true;
    }

    public async Task<string> SaveAsync(string folder, string originalFileName, Stream content, string contentType, CancellationToken ct = default)
    {
        await EnsureContainerAsync(ct);
        var name = $"{folder}/{Guid.NewGuid():N}{Path.GetExtension(originalFileName).ToLowerInvariant()}";
        var options = new BlobUploadOptions { HttpHeaders = new BlobHttpHeaders { ContentType = contentType } };
        await _container.GetBlobClient(name).UploadAsync(content, options, ct);
        return name;
    }

    public async Task<(Stream Content, string ContentType)?> OpenReadAsync(string blobName, CancellationToken ct = default)
    {
        await EnsureContainerAsync(ct);
        try
        {
            var response = await _container.GetBlobClient(blobName).DownloadStreamingAsync(cancellationToken: ct);
            return (response.Value.Content, response.Value.Details.ContentType ?? "application/octet-stream");
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            return null;
        }
    }

    public async Task DeleteAsync(string blobName, CancellationToken ct = default)
    {
        await EnsureContainerAsync(ct);
        await _container.GetBlobClient(blobName).DeleteIfExistsAsync(cancellationToken: ct);
    }
}

/// <summary>Development fallback used only when no Azure connection string is configured.</summary>
public class LocalFileStorage : IFileStorage
{
    private readonly string _root;

    public LocalFileStorage(string root)
    {
        _root = root;
        Directory.CreateDirectory(_root);
    }

    private string PathFor(string blobName) => Path.Combine(_root, blobName.Replace('/', Path.DirectorySeparatorChar));

    public async Task<string> SaveAsync(string folder, string originalFileName, Stream content, string contentType, CancellationToken ct = default)
    {
        var name = $"{folder}/{Guid.NewGuid():N}{Path.GetExtension(originalFileName).ToLowerInvariant()}";
        var path = PathFor(name);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await using var file = File.Create(path);
        await content.CopyToAsync(file, ct);
        return name;
    }

    public Task<(Stream Content, string ContentType)?> OpenReadAsync(string blobName, CancellationToken ct = default)
    {
        var path = PathFor(blobName);
        if (!File.Exists(path)) return Task.FromResult<(Stream Content, string ContentType)?>(null);
        var type = Path.GetExtension(path).ToLowerInvariant() switch
        {
            ".png" => "image/png", ".gif" => "image/gif", ".webp" => "image/webp", _ => "image/jpeg"
        };
        return Task.FromResult<(Stream Content, string ContentType)?>((File.OpenRead(path), type));
    }

    public Task DeleteAsync(string blobName, CancellationToken ct = default)
    {
        var path = PathFor(blobName);
        if (File.Exists(path)) File.Delete(path);
        return Task.CompletedTask;
    }
}
