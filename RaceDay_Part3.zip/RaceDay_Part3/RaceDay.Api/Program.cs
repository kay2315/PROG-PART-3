using System.Net.Mail;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<RaceDayContext>(o => o.UseSqlServer(builder.Configuration.GetConnectionString("RaceDay")));
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(o => { o.Cookie.HttpOnly = true; o.Cookie.IsEssential = true; o.Cookie.SameSite = SameSiteMode.Lax; o.IdleTimeout = TimeSpan.FromMinutes(30); });
builder.Services.AddScoped<IPasswordHasher<AppUser>, PasswordHasher<AppUser>>();
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles);

// Azure Blob Storage when a connection string is configured; local-disk fallback for quick development only.
builder.Services.AddSingleton<IFileStorage>(sp =>
{
    var cfg = sp.GetRequiredService<IConfiguration>();
    var conn = cfg["BlobStorage:ConnectionString"];
    if (!string.IsNullOrWhiteSpace(conn))
        return new AzureBlobFileStorage(conn, cfg["BlobStorage:ContainerName"] ?? "raceday-images");
    sp.GetRequiredService<ILogger<LocalFileStorage>>().LogWarning("BlobStorage:ConnectionString is not set - using local disk storage (development only).");
    var root = cfg["BlobStorage:LocalPath"] ?? Path.Combine(sp.GetRequiredService<IWebHostEnvironment>().ContentRootPath, "App_Data", "uploads");
    return new LocalFileStorage(root);
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
await DbInitializer.InitialiseAsync(app.Services, app.Configuration, app.Logger);
app.UseSession();
app.UseSwagger(); app.UseSwaggerUI();
app.MapGet("/", () => Results.Redirect("/swagger"));

// ---------- helpers ----------
static int? UserId(HttpContext c) => int.TryParse(c.Session.GetString("UserId"), out var id) ? id : null;
static string? Role(HttpContext c) => c.Session.GetString("Role");
static bool IsRole(HttpContext c, string role) => UserId(c) is not null && Role(c) == role;
static IResult Deny(HttpContext c) => UserId(c) is null ? Results.Unauthorized() : Results.StatusCode(403);
static DateOnly Today() => DateOnly.FromDateTime(DateTime.UtcNow);
static bool IsValidEmail(string? e) => !string.IsNullOrWhiteSpace(e) && e.Length <= 255 && MailAddress.TryCreate(e.Trim(), out var a) && a.Address == e.Trim();
static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

static IQueryable<RaceEvent> EventQuery(RaceDayContext db) =>
    db.Events.AsNoTracking().Include(x => x.Organiser).Include(x => x.Categories).ThenInclude(c => c.Enrolments);
static IQueryable<Enrolment> EnrolmentQuery(RaceDayContext db) =>
    db.Enrolments.AsNoTracking().Include(x => x.Participant).Include(x => x.Category).ThenInclude(c => c!.Event).Include(x => x.Result);

static string? ValidateEvent(EventRequest r)
{
    if (string.IsNullOrWhiteSpace(r.EventName)) return "Event name is required.";
    if (r.EventName.Trim().Length > 150) return "Event name must be 150 characters or fewer.";
    if (r.EventType is not ("Running" or "Walking" or "Cycling")) return "EventType must be Running, Walking or Cycling.";
    if (string.IsNullOrWhiteSpace(r.Venue) || string.IsNullOrWhiteSpace(r.City) || string.IsNullOrWhiteSpace(r.Province)) return "Venue, city and province are required.";
    if (r.Status is not ("Upcoming" or "Open" or "Closed" or "Completed" or "Cancelled")) return "Status must be Upcoming, Open, Closed, Completed or Cancelled.";
    if (r.DistanceKm is not null && (r.DistanceKm <= 0 || r.DistanceKm > 9999)) return "Distance must be a positive number of kilometres.";
    return null;
}

static string? ValidateCategory(CategoryRequest r)
{
    if (string.IsNullOrWhiteSpace(r.CategoryName)) return "Category name is required.";
    if (r.CategoryName.Trim().Length > 100) return "Category name must be 100 characters or fewer.";
    if (r.DistanceKm <= 0) return "Distance must be positive.";
    if (r.EntryFee < 0) return "Entry fee cannot be negative.";
    if (r.MaximumParticipants is not null && r.MaximumParticipants <= 0) return "Maximum participants must be positive.";
    return null;
}

static string? ValidateResult(string status, int? position, int? seconds)
{
    if (status is not ("Finished" or "DNF" or "DNS" or "DSQ")) return "Result status must be Finished, DNF, DNS or DSQ.";
    if (position <= 0 || seconds <= 0) return "Position and time must be positive when supplied.";
    if (status == "Finished" && (position is null || seconds is null)) return "A finisher needs both a finishing position and a finish time.";
    return null;
}

static async Task<(IFormFile? File, string? Error)> ReadImageAsync(HttpContext c)
{
    if (!c.Request.HasFormContentType) return (null, "Send the image as multipart/form-data in a field named 'file'.");
    try
    {
        var form = await c.Request.ReadFormAsync();
        var file = form.Files.GetFile("file");
        if (file is null) return (null, "No image was uploaded.");
        var error = ImageRules.Validate(file.FileName, file.ContentType, file.Length);
        if (error is not null) return (null, error);
        return (file, null);
    }
    catch (Exception ex) when (ex is InvalidDataException or BadHttpRequestException)
    {
        return (null, "The upload could not be read. Please try a different image.");
    }
}

// ---------- auth ----------
var auth = app.MapGroup("/api/auth");
auth.MapPost("/register", async (RegisterRequest r, RaceDayContext db, IPasswordHasher<AppUser> hasher) => {
    if (string.IsNullOrWhiteSpace(r.FirstName) || string.IsNullOrWhiteSpace(r.LastName)) return Results.BadRequest("First name and last name are required.");
    if (r.FirstName.Trim().Length > 50 || r.LastName.Trim().Length > 50) return Results.BadRequest("Names must be 50 characters or fewer.");
    if (!IsValidEmail(r.Email)) return Results.BadRequest("Please provide a valid email address.");
    if (string.IsNullOrEmpty(r.Password) || r.Password.Length < 8) return Results.BadRequest("Password must be at least 8 characters.");
    if (r.Role is not ("Participant" or "Organiser")) return Results.BadRequest("Role must be Participant or Organiser.");
    var email = r.Email.Trim().ToLowerInvariant();
    if (await db.Users.AnyAsync(x => x.Email == email)) return Results.Conflict("Email already registered.");
    var u = new AppUser { FirstName = r.FirstName.Trim(), LastName = r.LastName.Trim(), Email = email, Role = r.Role };
    u.PasswordHash = hasher.HashPassword(u, r.Password); u.Profile = new UserProfile();
    db.Users.Add(u); await db.SaveChangesAsync();
    return Results.Created($"/api/users/{u.UserId}", new { u.UserId, u.FirstName, u.LastName, u.Email, u.Role });
}).WithSummary("Register a participant or organiser; password is securely hashed.");

auth.MapPost("/login", async (LoginRequest r, HttpContext c, RaceDayContext db, IPasswordHasher<AppUser> hasher) => {
    if (string.IsNullOrWhiteSpace(r.Email) || string.IsNullOrEmpty(r.Password)) return Results.Unauthorized();
    var email = r.Email.Trim().ToLowerInvariant();
    var u = await db.Users.Include(x => x.Profile).SingleOrDefaultAsync(x => x.Email == email);
    if (u is null || hasher.VerifyHashedPassword(u, u.PasswordHash, r.Password) == PasswordVerificationResult.Failed) return Results.Unauthorized();
    c.Session.SetString("UserId", u.UserId.ToString()); c.Session.SetString("Role", u.Role);
    return Results.Ok(new { message = "Login successful", user = u.ToDto(), authentication = "Session cookie" });
}).WithSummary("Log in and establish an authenticated session.");

auth.MapPost("/logout", (HttpContext c) => { c.Session.Clear(); return Results.NoContent(); }).WithSummary("End the current session.");

// ---------- users ----------
var users = app.MapGroup("/api/users");
users.MapGet("/me", async (HttpContext c, RaceDayContext db) => {
    var id = UserId(c); if (id is null) return Results.Unauthorized();
    var u = await db.Users.AsNoTracking().Include(x => x.Profile).FirstOrDefaultAsync(x => x.UserId == id);
    return u is null ? Results.NotFound() : Results.Ok(u.ToDto());
}).WithSummary("Get the current user's profile.");

users.MapPut("/me", async (ProfileUpdate r, HttpContext c, RaceDayContext db) => {
    var id = UserId(c); if (id is null) return Results.Unauthorized();
    var u = await db.Users.Include(x => x.Profile).FirstOrDefaultAsync(x => x.UserId == id);
    if (u is null) return Results.NotFound();
    if (r.FirstName is not null && (string.IsNullOrWhiteSpace(r.FirstName) || r.FirstName.Trim().Length > 50)) return Results.BadRequest("First name is required (max 50 characters).");
    if (r.LastName is not null && (string.IsNullOrWhiteSpace(r.LastName) || r.LastName.Trim().Length > 50)) return Results.BadRequest("Last name is required (max 50 characters).");
    var phone = Clean(r.Phone); var emergencyPhone = Clean(r.EmergencyContactPhone);
    var phonePattern = new Regex(@"^[0-9+()\-\s]{7,20}$");
    if (phone is not null && !phonePattern.IsMatch(phone)) return Results.BadRequest("Phone number is not valid.");
    if (emergencyPhone is not null && !phonePattern.IsMatch(emergencyPhone)) return Results.BadRequest("Emergency contact phone number is not valid.");
    if (r.DateOfBirth is not null && (r.DateOfBirth > Today() || r.DateOfBirth < Today().AddYears(-120))) return Results.BadRequest("Date of birth is not valid.");
    if (r.FirstName is not null) u.FirstName = r.FirstName.Trim();
    if (r.LastName is not null) u.LastName = r.LastName.Trim();
    u.Profile ??= new UserProfile { UserId = u.UserId };
    u.Profile.Phone = phone; u.Profile.DateOfBirth = r.DateOfBirth;
    u.Profile.EmergencyContactName = Clean(r.EmergencyContactName); u.Profile.EmergencyContactPhone = emergencyPhone;
    u.Profile.City = Clean(r.City); u.Profile.Province = Clean(r.Province);
    await db.SaveChangesAsync();
    return Results.Ok(u.ToDto());
}).WithSummary("Update the current user's profile.");

users.MapPost("/me/picture", async (HttpContext c, RaceDayContext db, IFileStorage storage) => {
    var id = UserId(c); if (id is null) return Results.Unauthorized();
    var (file, error) = await ReadImageAsync(c);
    if (file is null) return Results.BadRequest(error);
    var u = await db.Users.Include(x => x.Profile).FirstOrDefaultAsync(x => x.UserId == id);
    if (u is null) return Results.NotFound();
    await using var stream = file.OpenReadStream();
    var blobName = await storage.SaveAsync("profiles", file.FileName, stream, file.ContentType);
    var old = u.Profile?.ProfilePictureBlobName;
    u.Profile ??= new UserProfile { UserId = u.UserId };
    u.Profile.ProfilePictureBlobName = blobName;
    await db.SaveChangesAsync();
    if (old is not null) await storage.DeleteAsync(old);
    return Results.Ok(u.ToDto());
}).WithSummary("Upload the current user's profile picture to Azure Blob Storage (multipart field 'file').");

users.MapDelete("/me/picture", async (HttpContext c, RaceDayContext db, IFileStorage storage) => {
    var id = UserId(c); if (id is null) return Results.Unauthorized();
    var u = await db.Users.Include(x => x.Profile).FirstOrDefaultAsync(x => x.UserId == id);
    if (u?.Profile?.ProfilePictureBlobName is null) return Results.NoContent();
    var old = u.Profile.ProfilePictureBlobName; u.Profile.ProfilePictureBlobName = null;
    await db.SaveChangesAsync(); await storage.DeleteAsync(old);
    return Results.NoContent();
}).WithSummary("Remove the current user's profile picture.");

users.MapGet("/{id:int}", async (int id, HttpContext c, RaceDayContext db) => {
    if (UserId(c) is null) return Results.Unauthorized();
    var u = await db.Users.AsNoTracking().Include(x => x.Profile).Where(x => x.UserId == id).Select(x => new { x.UserId, x.FirstName, x.LastName, City = x.Profile != null ? x.Profile.City : null, Province = x.Profile != null ? x.Profile.Province : null }).FirstOrDefaultAsync();
    return u is null ? Results.NotFound() : Results.Ok(u);
}).WithSummary("Get a public profile by user ID (login required).");

users.MapGet("/me/enrolments", async (HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Participant")) return Deny(c);
    var id = UserId(c);
    var list = await EnrolmentQuery(db).Where(x => x.ParticipantId == id).OrderBy(x => x.Category!.Event!.EventDate).ToListAsync();
    return Results.Ok(list.Select(x => x.ToDto()).ToList());
}).WithSummary("List the current participant's enrolments with their status.");

users.MapGet("/me/results", async (HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Participant")) return Deny(c);
    var id = UserId(c);
    var mine = await db.Results.AsNoTracking()
        .Include(x => x.Enrolment).ThenInclude(x => x!.Category).ThenInclude(x => x!.Event)
        .Where(x => x.Enrolment!.ParticipantId == id)
        .OrderByDescending(x => x.Enrolment!.Category!.Event!.EventDate).ToListAsync();
    var categoryIds = mine.Select(x => x.Enrolment!.CategoryId).Distinct().ToList();
    var totals = await db.Results.AsNoTracking()
        .Where(x => x.ResultStatus == "Finished" && categoryIds.Contains(x.Enrolment!.CategoryId))
        .GroupBy(x => x.Enrolment!.CategoryId).Select(g => new { CategoryId = g.Key, Count = g.Count() })
        .ToDictionaryAsync(x => x.CategoryId, x => x.Count);
    return Results.Ok(mine.Select(x => new MyResultDto(x.ResultId, x.Enrolment!.Category!.EventId, x.Enrolment.Category.Event!.EventName, x.Enrolment.Category.Event.EventDate,
        x.Enrolment.Category.CategoryName, x.Enrolment.Category.DistanceKm, x.FinishPosition, x.FinishTimeSeconds, x.ResultStatus,
        totals.TryGetValue(x.Enrolment.CategoryId, out var n) ? n : 0)).ToList());
}).WithSummary("The participant's race history: event, date, category, time and position out of total finishers.");

// ---------- files ----------
app.MapGet("/api/files/{**blobName}", async (string blobName, IFileStorage storage) => {
    if (!ImageRules.IsSafeBlobName(blobName)) return Results.NotFound();
    var file = await storage.OpenReadAsync(blobName);
    return file is null ? Results.NotFound() : Results.Stream(file.Value.Content, file.Value.ContentType);
}).WithSummary("Stream an uploaded image (event banner or profile picture) from Azure Blob Storage.");

// ---------- organiser dashboard ----------
app.MapGet("/api/organiser/dashboard", async (HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var id = UserId(c);
    var owned = await EventQuery(db).Where(x => x.OrganiserId == id).OrderBy(x => x.EventDate).ToListAsync();
    var rows = owned.Select(e => new DashboardEventDto(e.EventId, e.EventName, e.EventType, e.EventDate, e.Status, e.Categories.Count,
        e.Categories.Sum(cat => cat.Enrolments.Count(x => x.EnrolmentStatus != "Cancelled")),
        e.Categories.Sum(cat => cat.Enrolments.Count(x => x.EnrolmentStatus == "Active" && x.PaymentStatus == "Pending")))).ToList();
    var today = Today();
    return Results.Ok(new DashboardDto(rows.Count, rows.Count(x => x.EventDate >= today && x.Status != "Cancelled"), rows.Sum(x => x.TotalEnrolments), rows.Sum(x => x.PendingPayments), rows));
}).WithSummary("Organiser dashboard: events created, enrolments per event and upcoming dates.");

// ---------- events ----------
var events = app.MapGroup("/api/events");
events.MapGet("/", async (RaceDayContext db, string? eventType, string? city, string? province, string? search, bool? upcomingOnly, DateOnly? dateFrom, DateOnly? dateTo) => {
    var q = EventQuery(db);
    if (upcomingOnly == true) { var today = Today(); q = q.Where(x => x.EventDate >= today && x.Status != "Cancelled" && x.Status != "Completed"); }
    if (!string.IsNullOrWhiteSpace(eventType)) q = q.Where(x => x.EventType == eventType);
    if (!string.IsNullOrWhiteSpace(city)) q = q.Where(x => x.City.Contains(city));
    if (!string.IsNullOrWhiteSpace(province)) q = q.Where(x => x.Province.Contains(province));
    if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.EventName.Contains(search) || x.Venue.Contains(search) || x.City.Contains(search));
    if (dateFrom is not null) q = q.Where(x => x.EventDate >= dateFrom);
    if (dateTo is not null) q = q.Where(x => x.EventDate <= dateTo);
    var list = await q.OrderBy(x => x.EventDate).ThenBy(x => x.StartTime).ToListAsync();
    return Results.Ok(list.Select(x => x.ToDto()).ToList());
}).WithSummary("List events with optional filters (type, city, province, search text, upcomingOnly, date range).");

events.MapGet("/{id:int}", async (int id, RaceDayContext db) => {
    var e = await EventQuery(db).FirstOrDefaultAsync(x => x.EventId == id);
    return e is null ? Results.NotFound() : Results.Ok(e.ToDto());
}).WithSummary("Get event details, banner URL and categories.");

events.MapPost("/", async (EventRequest r, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var error = ValidateEvent(r); if (error is not null) return Results.BadRequest(error);
    var e = new RaceEvent { OrganiserId = UserId(c)!.Value, EventName = r.EventName.Trim(), EventType = r.EventType, Description = Clean(r.Description), EventDate = r.EventDate, StartTime = r.StartTime, Venue = r.Venue.Trim(), City = r.City.Trim(), Province = r.Province.Trim(), Status = r.Status, DistanceKm = r.DistanceKm };
    db.Events.Add(e); await db.SaveChangesAsync();
    return Results.Created($"/api/events/{e.EventId}", (await EventQuery(db).FirstAsync(x => x.EventId == e.EventId)).ToDto());
}).WithSummary("Create an event as an organiser.");

events.MapPut("/{id:int}", async (int id, EventRequest r, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var e = await db.Events.FirstOrDefaultAsync(x => x.EventId == id);
    if (e is null) return Results.NotFound();
    if (e.OrganiserId != UserId(c)) return Results.StatusCode(403);
    var error = ValidateEvent(r); if (error is not null) return Results.BadRequest(error);
    e.EventName = r.EventName.Trim(); e.EventType = r.EventType; e.Description = Clean(r.Description); e.EventDate = r.EventDate; e.StartTime = r.StartTime;
    e.Venue = r.Venue.Trim(); e.City = r.City.Trim(); e.Province = r.Province.Trim(); e.Status = r.Status; e.DistanceKm = r.DistanceKm;
    await db.SaveChangesAsync();
    return Results.Ok((await EventQuery(db).FirstAsync(x => x.EventId == id)).ToDto());
}).WithSummary("Update an event owned by the signed-in organiser.");

events.MapDelete("/{id:int}", async (int id, HttpContext c, RaceDayContext db, IFileStorage storage) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var e = await db.Events.Include(x => x.Categories).ThenInclude(x => x.Enrolments).FirstOrDefaultAsync(x => x.EventId == id);
    if (e is null) return Results.NotFound();
    if (e.OrganiserId != UserId(c)) return Results.StatusCode(403);
    if (e.Categories.Any(x => x.Enrolments.Any())) { e.Status = "Cancelled"; await db.SaveChangesAsync(); return Results.NoContent(); }
    var banner = e.BannerBlobName;
    db.Events.Remove(e); await db.SaveChangesAsync();
    if (banner is not null) await storage.DeleteAsync(banner);
    return Results.NoContent();
}).WithSummary("Cancel (when it has enrolments) or delete an event owned by the organiser.");

events.MapPost("/{id:int}/banner", async (int id, HttpContext c, RaceDayContext db, IFileStorage storage) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var e = await db.Events.FirstOrDefaultAsync(x => x.EventId == id);
    if (e is null) return Results.NotFound();
    if (e.OrganiserId != UserId(c)) return Results.StatusCode(403);
    var (file, error) = await ReadImageAsync(c);
    if (file is null) return Results.BadRequest(error);
    await using var stream = file.OpenReadStream();
    var blobName = await storage.SaveAsync("banners", file.FileName, stream, file.ContentType);
    var old = e.BannerBlobName; e.BannerBlobName = blobName;
    await db.SaveChangesAsync();
    if (old is not null) await storage.DeleteAsync(old);
    return Results.Ok((await EventQuery(db).FirstAsync(x => x.EventId == id)).ToDto());
}).WithSummary("Upload or replace the event banner in Azure Blob Storage (multipart field 'file').");

events.MapDelete("/{id:int}/banner", async (int id, HttpContext c, RaceDayContext db, IFileStorage storage) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var e = await db.Events.FirstOrDefaultAsync(x => x.EventId == id);
    if (e is null) return Results.NotFound();
    if (e.OrganiserId != UserId(c)) return Results.StatusCode(403);
    if (e.BannerBlobName is null) return Results.NoContent();
    var old = e.BannerBlobName; e.BannerBlobName = null;
    await db.SaveChangesAsync(); await storage.DeleteAsync(old);
    return Results.NoContent();
}).WithSummary("Remove the event banner.");

events.MapGet("/{eventId:int}/categories", async (int eventId, RaceDayContext db) => {
    var list = await db.Categories.AsNoTracking().Include(x => x.Enrolments).Where(x => x.EventId == eventId).OrderBy(x => x.DistanceKm).ToListAsync();
    return Results.Ok(list.Select(x => x.ToDto()).ToList());
}).WithSummary("List categories for an event.");

events.MapPost("/{eventId:int}/categories", async (int eventId, CategoryRequest r, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var e = await db.Events.FirstOrDefaultAsync(x => x.EventId == eventId);
    if (e is null) return Results.NotFound();
    if (e.OrganiserId != UserId(c)) return Results.StatusCode(403);
    var error = ValidateCategory(r); if (error is not null) return Results.BadRequest(error);
    var name = r.CategoryName.Trim();
    if (await db.Categories.AnyAsync(x => x.EventId == eventId && x.CategoryName == name)) return Results.Conflict("This event already has a category with that name.");
    var cat = new RaceCategory { EventId = eventId, CategoryName = name, DistanceKm = r.DistanceKm, EntryFee = r.EntryFee, MaximumParticipants = r.MaximumParticipants };
    db.Categories.Add(cat); await db.SaveChangesAsync();
    return Results.Created($"/api/categories/{cat.CategoryId}", cat.ToDtoWithoutEnrolments());
}).WithSummary("Add an age or distance category to an event.");

events.MapGet("/{eventId:int}/enrolments", async (int eventId, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var e = await db.Events.AsNoTracking().FirstOrDefaultAsync(x => x.EventId == eventId);
    if (e is null) return Results.NotFound();
    if (e.OrganiserId != UserId(c)) return Results.StatusCode(403);
    var list = await EnrolmentQuery(db).Where(x => x.Category!.EventId == eventId).OrderBy(x => x.Category!.CategoryName).ThenBy(x => x.EnrolmentDate).ToListAsync();
    return Results.Ok(list.Select(x => x.ToDto()).ToList());
}).WithSummary("List enrolments (participant, category, status, result) for an event owned by the organiser.");

events.MapPost("/{eventId:int}/enrolments", async (int eventId, EnrolmentRequest r, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Participant")) return Deny(c);
    var participantId = UserId(c)!.Value;
    var cat = await db.Categories.Include(x => x.Event).FirstOrDefaultAsync(x => x.CategoryId == r.CategoryId && x.EventId == eventId);
    if (cat is null) return Results.BadRequest("Category does not belong to this event.");
    if (cat.Event!.EventDate < Today()) return Results.BadRequest("This event has already taken place.");
    if (cat.Event.Status is "Closed" or "Completed" or "Cancelled") return Results.BadRequest($"Enrolment is not available because this event is {cat.Event.Status.ToLowerInvariant()}.");
    var existing = await db.Enrolments.FirstOrDefaultAsync(x => x.ParticipantId == participantId && x.CategoryId == cat.CategoryId);
    if (existing is not null && existing.EnrolmentStatus != "Cancelled") return Results.Conflict("Already enrolled in this category.");
    var count = await db.Enrolments.CountAsync(x => x.CategoryId == cat.CategoryId && x.EnrolmentStatus != "Cancelled");
    if (cat.MaximumParticipants is not null && count >= cat.MaximumParticipants) return Results.Conflict("Category is full.");
    Enrolment en;
    if (existing is not null) { existing.EnrolmentStatus = "Active"; existing.PaymentStatus = "Pending"; existing.EnrolmentDate = DateTime.UtcNow; en = existing; }
    else { en = new Enrolment { ParticipantId = participantId, CategoryId = cat.CategoryId }; db.Enrolments.Add(en); }
    await db.SaveChangesAsync();
    return Results.Created($"/api/enrolments/{en.EnrolmentId}", (await EnrolmentQuery(db).FirstAsync(x => x.EnrolmentId == en.EnrolmentId)).ToDto());
}).WithSummary("Enrol the signed-in participant in a category; recorded immediately as Pending.");

events.MapGet("/{eventId:int}/results", async (int eventId, RaceDayContext db) => {
    if (!await db.Events.AnyAsync(x => x.EventId == eventId)) return Results.NotFound();
    var list = await db.Results.AsNoTracking().Include(x => x.Enrolment).ThenInclude(x => x!.Category).Include(x => x.Enrolment).ThenInclude(x => x!.Participant)
        .Where(x => x.Enrolment!.Category!.EventId == eventId).ToListAsync();
    return Results.Ok(list.OrderBy(x => x.Enrolment!.Category!.CategoryName).ThenBy(x => x.FinishPosition ?? int.MaxValue)
        .Select(x => new EventResultDto(x.ResultId, x.EnrolmentId, $"{x.Enrolment!.Participant!.FirstName} {x.Enrolment.Participant.LastName}", x.Enrolment.RaceNumber,
            x.Enrolment.CategoryId, x.Enrolment.Category!.CategoryName, x.FinishPosition, x.FinishTimeSeconds, x.ResultStatus)).ToList());
}).WithSummary("View published results for an event.");

events.MapPost("/{eventId:int}/results", async (int eventId, ResultRequest r, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var e = await db.Events.FirstOrDefaultAsync(x => x.EventId == eventId);
    if (e is null) return Results.NotFound();
    if (e.OrganiserId != UserId(c)) return Results.StatusCode(403);
    if (e.EventDate > Today()) return Results.BadRequest("Results can only be recorded once the event has taken place.");
    var en = await db.Enrolments.Include(x => x.Category).FirstOrDefaultAsync(x => x.EnrolmentId == r.EnrolmentId && x.Category!.EventId == eventId);
    if (en is null) return Results.BadRequest("Enrolment does not belong to this event.");
    if (en.EnrolmentStatus == "Cancelled") return Results.BadRequest("A cancelled enrolment cannot have a result.");
    if (await db.Results.AnyAsync(x => x.EnrolmentId == r.EnrolmentId)) return Results.Conflict("A result already exists for this enrolment.");
    var error = ValidateResult(r.ResultStatus, r.FinishPosition, r.FinishTimeSeconds); if (error is not null) return Results.BadRequest(error);
    if (r.ResultStatus == "Finished" && await db.Results.AnyAsync(x => x.Enrolment!.CategoryId == en.CategoryId && x.ResultStatus == "Finished" && x.FinishPosition == r.FinishPosition))
        return Results.Conflict($"Position {r.FinishPosition} has already been awarded in this category.");
    var result = new RaceResult { EnrolmentId = r.EnrolmentId, FinishPosition = r.FinishPosition, FinishTimeSeconds = r.FinishTimeSeconds, ResultStatus = r.ResultStatus };
    db.Results.Add(result);
    if (en.EnrolmentStatus == "Active") en.EnrolmentStatus = "Completed";
    await db.SaveChangesAsync();
    return Results.Created($"/api/results/{result.ResultId}", result.ToDto());
}).WithSummary("Record a finish time and position for an enrolment once the event has taken place.");

// ---------- categories ----------
var categories = app.MapGroup("/api/categories");
categories.MapPut("/{id:int}", async (int id, CategoryRequest r, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var cat = await db.Categories.Include(x => x.Event).Include(x => x.Enrolments).FirstOrDefaultAsync(x => x.CategoryId == id);
    if (cat is null) return Results.NotFound();
    if (cat.Event!.OrganiserId != UserId(c)) return Results.StatusCode(403);
    var error = ValidateCategory(r); if (error is not null) return Results.BadRequest(error);
    var name = r.CategoryName.Trim();
    if (await db.Categories.AnyAsync(x => x.EventId == cat.EventId && x.CategoryName == name && x.CategoryId != id)) return Results.Conflict("This event already has a category with that name.");
    cat.CategoryName = name; cat.DistanceKm = r.DistanceKm; cat.EntryFee = r.EntryFee; cat.MaximumParticipants = r.MaximumParticipants;
    await db.SaveChangesAsync();
    return Results.Ok(cat.ToDto());
}).WithSummary("Update a category owned by the organiser.");

categories.MapDelete("/{id:int}", async (int id, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var cat = await db.Categories.Include(x => x.Event).Include(x => x.Enrolments).FirstOrDefaultAsync(x => x.CategoryId == id);
    if (cat is null) return Results.NotFound();
    if (cat.Event!.OrganiserId != UserId(c)) return Results.StatusCode(403);
    if (cat.Enrolments.Count > 0) return Results.Conflict("Cannot delete a category with enrolments.");
    db.Categories.Remove(cat); await db.SaveChangesAsync();
    return Results.NoContent();
}).WithSummary("Delete a category if no enrolments exist.");

// ---------- enrolments ----------
var enrolments = app.MapGroup("/api/enrolments");
enrolments.MapPut("/{id:int}", async (int id, EnrolmentUpdate r, HttpContext c, RaceDayContext db) => {
    if (UserId(c) is null) return Results.Unauthorized();
    var en = await db.Enrolments.Include(x => x.Category).ThenInclude(x => x!.Event).FirstOrDefaultAsync(x => x.EnrolmentId == id);
    if (en is null) return Results.NotFound();
    var isParticipant = Role(c) == "Participant" && en.ParticipantId == UserId(c);
    var isOrganiser = Role(c) == "Organiser" && en.Category!.Event!.OrganiserId == UserId(c);
    if (!isParticipant && !isOrganiser) return Results.StatusCode(403);
    if (isParticipant && (r.PaymentStatus is not null || r.EnrolmentStatus is not (null or "Cancelled"))) return Results.StatusCode(403);
    if (r.PaymentStatus is not null && r.PaymentStatus is not ("Pending" or "Paid" or "Refunded" or "Waived")) return Results.BadRequest("PaymentStatus must be Pending, Paid, Refunded or Waived.");
    if (r.EnrolmentStatus is not null && r.EnrolmentStatus is not ("Active" or "Cancelled" or "Completed")) return Results.BadRequest("EnrolmentStatus must be Active, Cancelled or Completed.");
    if (r.PaymentStatus is not null) en.PaymentStatus = r.PaymentStatus;
    if (r.EnrolmentStatus is not null) en.EnrolmentStatus = r.EnrolmentStatus;
    await db.SaveChangesAsync();
    return Results.Ok((await EnrolmentQuery(db).FirstAsync(x => x.EnrolmentId == id)).ToDto());
}).WithSummary("Update permitted enrolment/payment status (organiser: payment & status; participant: cancel own).");

enrolments.MapDelete("/{id:int}", async (int id, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Participant")) return Deny(c);
    var en = await db.Enrolments.FirstOrDefaultAsync(x => x.EnrolmentId == id);
    if (en is null) return Results.NotFound();
    if (en.ParticipantId != UserId(c)) return Results.StatusCode(403);
    en.EnrolmentStatus = "Cancelled"; await db.SaveChangesAsync();
    return Results.NoContent();
}).WithSummary("Cancel your own enrolment.");

// ---------- results ----------
var results = app.MapGroup("/api/results");
results.MapPut("/{id:int}", async (int id, ResultUpdate r, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var result = await db.Results.Include(x => x.Enrolment).ThenInclude(x => x!.Category).ThenInclude(x => x!.Event).FirstOrDefaultAsync(x => x.ResultId == id);
    if (result is null) return Results.NotFound();
    if (result.Enrolment!.Category!.Event!.OrganiserId != UserId(c)) return Results.StatusCode(403);
    var error = ValidateResult(r.ResultStatus, r.FinishPosition, r.FinishTimeSeconds); if (error is not null) return Results.BadRequest(error);
    if (r.ResultStatus == "Finished" && await db.Results.AnyAsync(x => x.ResultId != id && x.Enrolment!.CategoryId == result.Enrolment.CategoryId && x.ResultStatus == "Finished" && x.FinishPosition == r.FinishPosition))
        return Results.Conflict($"Position {r.FinishPosition} has already been awarded in this category.");
    result.FinishPosition = r.FinishPosition; result.FinishTimeSeconds = r.FinishTimeSeconds; result.ResultStatus = r.ResultStatus; result.RecordedAt = DateTime.UtcNow;
    await db.SaveChangesAsync();
    return Results.Ok(result.ToDto());
}).WithSummary("Correct a recorded result.");

results.MapDelete("/{id:int}", async (int id, HttpContext c, RaceDayContext db) => {
    if (!IsRole(c, "Organiser")) return Deny(c);
    var result = await db.Results.Include(x => x.Enrolment).ThenInclude(x => x!.Category).ThenInclude(x => x!.Event).FirstOrDefaultAsync(x => x.ResultId == id);
    if (result is null) return Results.NotFound();
    if (result.Enrolment!.Category!.Event!.OrganiserId != UserId(c)) return Results.StatusCode(403);
    db.Results.Remove(result); await db.SaveChangesAsync();
    return Results.NoContent();
}).WithSummary("Delete an incorrect result.");

// ---------- placeholders carried over from Part 2 ----------
app.MapGet("/api/events/{eventId:int}/weather", async (int eventId, RaceDayContext db) =>
    await db.Events.AnyAsync(x => x.EventId == eventId) ? Results.Problem("Configure a weather provider API key to enable live forecasts.", statusCode: 502) : Results.NotFound())
    .WithSummary("Weather endpoint placeholder; connect a weather provider to enable live forecasts.");
app.MapGet("/api/events/{eventId:int}/route", async (int eventId, RaceDayContext db) => {
    var e = await db.Events.Where(x => x.EventId == eventId).Select(x => new { x.EventId, x.EventName, x.Venue, x.City, x.Province }).FirstOrDefaultAsync();
    return e is null ? Results.NotFound() : Results.Ok(new { @event = e, routeInformation = "Route/map data must be supplied by the event organiser." });
}).WithSummary("Return event location and route information placeholder.");

app.Run();
